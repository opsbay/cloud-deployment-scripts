import * as config from 'config';
import { MetadataBuilder } from 'routing-controllers/metadata-builder/MetadataBuilder';
import { ParamTypes } from 'routing-controllers/metadata/types/ParamTypes';
import { UseMetadata } from 'routing-controllers/metadata/UseMetadata';
import { Service } from 'typedi';

export interface ISwaggerConfig {
  basePath: string;
  info: Object;
  host?: string;
  paths: Object;
  swagger: string;
}

@Service()
export class SwaggerDefinition {

  spec: ISwaggerConfig;

  constructor() {
    this.config();
  }

  getSpec(): ISwaggerConfig {
    return this.spec;
  }

  private config(): void {
    this.spec = config.get('swagger') as ISwaggerConfig;
    const env = process.env;
    this.spec.info = {
      title: env.npm_package_name,
      version: env.npm_package_version,
    };
    this.spec.paths = this.getSwaggerPaths();
  }

  private getSwaggerPaths() {
    const metadataBuilder: MetadataBuilder = new MetadataBuilder();
    const controllers = metadataBuilder.buildControllerMetadata();

    let paths: any = {};

    controllers.forEach(controller => {
      controller.actions.forEach(action => {
        let route = '' + action.fullRoute;

        if (!paths[route]) {
          paths[route] = {};
        }

        let uses: any = [];

        action.uses.forEach((useMetada: UseMetadata) => {
          if (useMetada.afterAction) {
            uses.push(`+${useMetada.middleware.name}`);
          } else {
            uses.push(`-${useMetada.middleware.name}`);
          }
        });

        uses.sort();

        let description = (uses.length > 0 ? (`(${uses.join(', ')})`) : '');
        let type = {
          operationId: action.method,
          description: description,
          produces: [] as string[],
          parameters: [] as Object[],
          tags: [] as string[],
        };

        if (controller.route) {
          type.tags = [controller.route];
        }

        if (action.jsonResponse || action.isJsonTyped) {
          type.produces = ['application/json'];
        } else if (action.contentTypeHandler && action.contentTypeHandler.value) {
          type.produces = [action.contentTypeHandler.value];
        }

        action.params.forEach(param => {
          let typeParameter = {
            in: param.type,
            name: param.name || null,
            type: param.reflectedType.name || null,
            required: param.isRequired || false,
          };

          switch (param.type) {
            case ParamTypes.RESPONSE:
            case ParamTypes.REQUEST:
              typeParameter = null;
              break;
            case ParamTypes.BODY:
              break;
            case ParamTypes.UPLOADED_FILE:
              typeParameter.type = param.type;
              break;
            case ParamTypes.UPLOADED_FILES:
              delete typeParameter.type;
              break;
          }

          if (typeParameter) {
            type.parameters.push(typeParameter);
          }
        });

        paths[route][action.type] = type;
      });
    });

    return paths;
  }
}
