import 'reflect-metadata';
import * as helmet from 'helmet';
import { Container } from 'typedi';
import { Get, JsonController, QueryParam, UseBefore } from 'routing-controllers';

import { OrganizationsRepository } from '../../repositories';

@UseBefore(helmet())
@JsonController('/organizations')
export class OrganizationsController {
  private organizationsRepo: OrganizationsRepository;

  constructor() {
    this.organizationsRepo = Container.get(OrganizationsRepository);
  }

  @Get('/search')
  public async search(@QueryParam('filter') filter?: any,
                      @QueryParam('page') page?: number,
                      @QueryParam('limit') limit?: number): Promise<any> {

    return await this.organizationsRepo.search(filter, page, limit);
  }
}
