import * as helmet from 'helmet';
import 'reflect-metadata';
import { Container } from 'typedi';
import { Get, JsonController, QueryParam, UseBefore } from 'routing-controllers';

import { CareerRepository, CareerClusterRepository } from '../../repositories';

@UseBefore(helmet())
@JsonController('/career')
export class CareerController {
  private repository: CareerRepository;
  private careerClusterRepository: CareerClusterRepository;

  constructor() {
    this.repository = Container.get(CareerRepository);
    this.careerClusterRepository = Container.get(CareerClusterRepository);
  }

  @Get('/search')
  public async search(@QueryParam('filter') filter?: any,
                      @QueryParam('page') page?: number,
                      @QueryParam('limit') limit?: number): Promise<any> {

    return await this.repository.search(filter, page, limit);
  }

  @Get('/searchClusters')
  public async searchClusters(@QueryParam('filter') filter?: any,
                      @QueryParam('page') page?: number,
                      @QueryParam('limit') limit?: number): Promise<any> {

    return await this.careerClusterRepository.search(filter, page, limit);
  }
}
