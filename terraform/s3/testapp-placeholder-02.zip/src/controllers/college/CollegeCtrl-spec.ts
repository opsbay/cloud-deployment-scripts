import 'reflect-metadata';
import * as request from 'supertest';

import { createTestApp, TestApp } from '../../mocks/mock-app';
import { CollegeController } from './';

let app: TestApp;
let ctrl: CollegeController;

beforeAll(async () => {
  app = await createTestApp();
  ctrl = new CollegeController();
});

afterAll(() => {
  app.destroy();
});

describe('methods calls', () => {
  it('should call the method', async () => {
    const response = await ctrl.search();
    expect(response).not.toBe(null);
  });

  it('should call the method', async () => {
    const response = await ctrl.groupSearch();
    expect(response).not.toBe(null);
  });
});

describe('http requests', () => {
  it('should make a GET request', async () => {
    const response = await request(app.getServer()).get('/college/search');
    expect(response).not.toBe(null);
    expect(response.status).toBe(200);
  });

  it('should make a GET request', async () => {
    const response = await request(app.getServer()).get('/college/group-search');
    expect(response).not.toBe(null);
    expect(response.status).toBe(200);
  });
});
