export * from './CollegeCtrl';
