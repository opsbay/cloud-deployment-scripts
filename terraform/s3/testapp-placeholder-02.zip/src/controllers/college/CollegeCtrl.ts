import 'reflect-metadata';
import * as helmet from 'helmet';
import { Container } from 'typedi';
import { Get, JsonController, QueryParam, UseBefore } from 'routing-controllers';

import { CollegeRepository, CollegeGroupRepository } from '../../repositories';

@UseBefore(helmet())
@JsonController('/college')
export class CollegeController {
  private collegeRepo: CollegeRepository;
  private collegeGroupRepo: CollegeGroupRepository;

  constructor() {
    this.collegeRepo = Container.get(CollegeRepository);
    this.collegeGroupRepo = Container.get(CollegeGroupRepository);
  }

  @Get('/search')
  public async search(@QueryParam('filter') filter?: any,
                      @QueryParam('page') page?: number,
                      @QueryParam('limit') limit?: number): Promise<any> {

    return await this.collegeRepo.search(filter, page, limit);
  }

  @Get('/group-search')
  public async groupSearch(@QueryParam('filter') filter?: any,
                           @QueryParam('page') page?: number,
                           @QueryParam('limit') limit?: number): Promise<any> {

    return await this.collegeGroupRepo.search(filter, page, limit);
  }
}
