import 'reflect-metadata';
import * as helmet from 'helmet';
import { Container } from 'typedi';
import { Get, JsonController, QueryParam, UseBefore } from 'routing-controllers';

import { MajorsRepository } from '../../repositories';

@UseBefore(helmet())
@JsonController('/majors')
export class MajorsController {
  private majorsRepo: MajorsRepository;

  constructor() {
    this.majorsRepo = Container.get(MajorsRepository);
  }

  @Get('/search')
  public async search(@QueryParam('filter') filter?: any,
                      @QueryParam('page') page?: number,
                      @QueryParam('limit') limit?: number): Promise<any> {

    return await this.majorsRepo.search(filter, page, limit);
  }
}
