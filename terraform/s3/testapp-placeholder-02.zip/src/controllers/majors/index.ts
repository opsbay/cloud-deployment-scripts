export * from './MajorsCtrl';
