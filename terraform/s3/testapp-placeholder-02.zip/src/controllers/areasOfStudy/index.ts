export * from './AreasOfStudyCtrl';
