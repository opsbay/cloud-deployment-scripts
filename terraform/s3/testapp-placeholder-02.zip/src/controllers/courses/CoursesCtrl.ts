import * as helmet from 'helmet';
import 'reflect-metadata';
import { Container } from 'typedi';
import { Get, JsonController, QueryParam, UseBefore } from 'routing-controllers';

import { CoursesRepository } from '../../repositories';

@UseBefore(helmet())
@JsonController('/courses')
export class CoursesController {
  private repository: CoursesRepository;

  constructor() {
    this.repository = Container.get(CoursesRepository);
  }

  @Get('/search')
  public search(@QueryParam('filter') filter?: any,
                @QueryParam('limit') limit?: number,
                @QueryParam('offset') offset?: number): Promise<any> {

    return new Promise<any>((resolve: Function, reject: Function) => {
      this.repository.search(filter, limit, offset)
        .then(res => resolve(res))
        .catch(err => reject(err));
    });
  }
}
