import * as request from 'supertest';
import 'reflect-metadata';

import { createTestApp, TestApp } from '../../mocks/mock-app';
import { CoursesController } from './';

let app: TestApp;
let coursesController: CoursesController;

beforeAll(async () => {
  app = await createTestApp();
  coursesController = new CoursesController();
});

afterAll(() => {
  app.destroy();
});

describe('list courses', () => {
  it('should call the method search', async () => {
    const response = await coursesController.search();
    expect(response).not.toBe(null);
  });
});

describe('GET /courses/search', () => {
  it('should provide a course search', async () => {
    const response = await request(app.getServer()).get('/courses/search');
    expect(response.status).toBe(200);
  });
});
