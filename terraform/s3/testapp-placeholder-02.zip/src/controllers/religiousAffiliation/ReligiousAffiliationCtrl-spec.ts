import 'reflect-metadata';
import * as request from 'supertest';

import { createTestApp, TestApp } from '../../mocks/mock-app';
import { ReligiousAffiliationController } from './';

let app: TestApp;
let ctrl: ReligiousAffiliationController;

beforeAll(async () => {
  app = await createTestApp();
  ctrl = new ReligiousAffiliationController();
});

afterAll(() => {
  app.destroy();
});

describe('methods calls', () => {
  it('should call the method', async () => {
    const response = await ctrl.search();
    expect(response).not.toBe(null);
  });
});

describe('http requests', () => {
  it('should make a GET request', async () => {
    const response = await request(app.getServer()).get('/religious-affiliation/search');
    expect(response).not.toBe(null);
    expect(response.status).toBe(200);
  });
});
