import {Entity, PrimaryGeneratedColumn, OneToOne, JoinColumn, Column} from 'typeorm';

import { FcOptions } from './FcOptionsModel';
import { FcNewsDisplayTo } from './FcNewsDisplayToModel';

@Entity()
export class FcNews {
    @PrimaryGeneratedColumn()
    id: number;

    @Column('smallint', {
      name: 'grade_levels',
      length: 5,
    })
    gradeLevels: number;

    @Column('int', {
      name: 'for_guests',
      length: 3,
    })
    forGuests: number;

    @Column('string', {
      length: 255,
    })
    headline: string;

    @Column('text', {
      name: 'news_html',
    })
    news: string;

    @Column('datetime', {
      name: 'start_date',
    })
    startDate: Date;

    @Column('datetime', {
      name: 'end_date',
    })
    endDate: Date;

    @Column('datetime', {
      name: 'date_created',
    })
    dateCreated: Date;

    @OneToOne(type => FcOptions)
    @JoinColumn({
      name: 'fk_highschool_id',
    })
    highschoolId: FcOptions;

    @OneToOne(type => FcNewsDisplayTo, fcNewsDisplayTo => fcNewsDisplayTo.newsId)
    displayTo: FcNewsDisplayTo;
}
