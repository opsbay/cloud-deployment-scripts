import { Entity, Column, PrimaryColumn } from 'typeorm';

@Entity()
export class HighschoolProduct {
  @PrimaryColumn('string')
  id: string;

  @Column('string')
  name: string;
}
