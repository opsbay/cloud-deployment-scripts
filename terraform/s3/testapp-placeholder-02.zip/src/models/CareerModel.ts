import {Entity, Column, PrimaryColumn} from 'typeorm';

@Entity('onet_career_description')
export class Career {

    @Column('int', {
      unique: true,
    })
    id: number;

    @PrimaryColumn('string', {
      name: 'onet_code',
    })
    onetCode: string;

    @Column('smallint', {
      name: 'onet_category',
    })
    onetCategory: number;

    @Column('string', {
      length: 7,
      name: 'occ_code',
    })
    occCode: string;

    @Column('string', {
      length: 50,
      name: 'category_name',
    })
    categoryName: string;

    @Column('string', {
      length: 150,
    })
    title: string;

    @Column('text')
    description: string;

    @Column('string', {
      length: 255,
    })
    keywords: string;

    @Column('text', {
      name: 'search_terms',
    })
    searchTerms: string;

    @Column('text')
    aliases: string;

    @Column('smallint', {
      name: 'job_zone',
    })
    jobZone: number;

    @Column('string', {
      length: 1,
      name: 'first_holland',
    })
    firstHolland: string;

    @Column('string', {
      length: 1,
      name: 'second_holland',
    })
    secondHolland: string;

    @Column('string', {
      length: 1,
      name: 'third_holland',
    })
    thirdHolland: string;
}
