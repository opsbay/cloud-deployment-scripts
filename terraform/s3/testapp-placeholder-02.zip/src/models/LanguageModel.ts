import {Entity, PrimaryColumn} from 'typeorm';

@Entity()
export class Language {
    @PrimaryColumn('int')
    id: number;
}
