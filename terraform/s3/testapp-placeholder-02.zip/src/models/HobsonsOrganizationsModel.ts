import { Entity, Column, PrimaryColumn } from 'typeorm';

@Entity('hobsons_organizations')
export class HobsonsOrganizations {
  @PrimaryColumn('string', {
    name: 'hobsons_id',
  })
  id: string;

  @Column('string')
  name: string;
}
