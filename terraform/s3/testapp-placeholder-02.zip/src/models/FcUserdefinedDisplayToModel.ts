import {Entity, PrimaryColumn, OneToOne, JoinColumn } from 'typeorm';

import { FcUserdefined } from './FcUserdefinedModel';
@Entity()
export class FcUserdefinedDisplayTo {

    @PrimaryColumn({
      name: 'fk_language_id',
    })
    languageId: string;

    @OneToOne(type => FcUserdefined)
    @JoinColumn({
      name: 'fk_fc_userdefined_id',
    })
    userdefinedId: FcUserdefined;
}
