import { Entity, PrimaryColumn } from 'typeorm';

@Entity()
export class FcOptions {
  @PrimaryColumn('string', {
    name: 'fk_highschool_id',
  })
  highschoolId: string;
}
