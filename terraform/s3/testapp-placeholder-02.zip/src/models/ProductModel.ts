import { Entity, Column, PrimaryColumn } from 'typeorm';

@Entity('products')
export class Product {
  @PrimaryColumn('string')
  id: string;

  @Column('string')
  name: string;
}
