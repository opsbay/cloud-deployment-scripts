import {Entity, PrimaryGeneratedColumn, Column, OneToOne, JoinColumn} from 'typeorm';

import { FcOptions } from './FcOptionsModel';
import { FcWelcomeTranslations } from './FcWelcomeTranslationsModel';

@Entity()
export class FcWelcome {

    @PrimaryGeneratedColumn()
    id: number;

    @Column('string', {
      name: 'label',
      length: 50,
    })
    title: string;

    @Column('smallint', {
      name: 'grade_levels',
      length: 5,
    })
    gradeLevels: number;

    @Column('int', {
      name: 'for_guests',
      length: 3,
    })
    forGuests: number;

    @Column('text', {
      name: 'welcome_html',
    })
    welcome: string;

    @OneToOne(type => FcOptions)
    @JoinColumn({
      name: 'fk_highschool_id',
    })
    highschoolId: FcOptions;

    @OneToOne(type => FcWelcomeTranslations, translation => translation.welcomeId)
    translation: FcWelcomeTranslations;
}
