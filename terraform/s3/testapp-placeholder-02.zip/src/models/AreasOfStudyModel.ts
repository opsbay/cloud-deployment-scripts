import { Entity, Column, PrimaryColumn } from 'typeorm';

@Entity('hobsons_areas_of_study')
export class AreasOfStudy {
  @PrimaryColumn('string', {
    name: 'hobsons_id',
  })
  id: string;

  @Column('string')
  name: string;
}
