import { Entity, Column, PrimaryColumn } from 'typeorm';

@Entity('hobsons_majors')
export class Majors {
  @PrimaryColumn('string', {
    name: 'hobsons_id',
  })
  id: string;

  @Column('string')
  name: string;

  @Column('int', {
    name: 'area_of_study_id',
  })
  areaOfStudyId: string;
}
