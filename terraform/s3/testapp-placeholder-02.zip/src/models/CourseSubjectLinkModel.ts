import { Entity, PrimaryColumn, Column } from 'typeorm';

@Entity()
export class CourseSubjectLink {
  @PrimaryColumn('int', {
    name: 'fk_course_id',
  })
  courseId: number;

  @Column('int', {
    name: 'fk_subject_area_id',
  })
  subjectAreaId: number;
}
