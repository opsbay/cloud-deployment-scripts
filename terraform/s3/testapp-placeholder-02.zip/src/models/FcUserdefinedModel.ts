import {Entity, PrimaryGeneratedColumn, OneToOne, JoinColumn, Column} from 'typeorm';

import { FcOptions } from './FcOptionsModel';
import { FcUserdefinedDisplayTo } from './FcUserdefinedDisplayToModel';

@Entity()
export class FcUserdefined {

    @PrimaryGeneratedColumn()
    id: number;

    @Column('string', {
      length: 255,
    })
    name: string;

    @Column('string', {
      length: 255,
    })
    url: string;

    @Column('text', {
      name: 'html_body',
    })
    html: string;

    @Column('smallint', {
      name: 'protect',
      length: 3,
    })
    protect: number;

    @Column('smallint', {
      name: 'display_order',
      length: 3,
    })
    displayOrder: number;

    @Column('smallint', {
      name: 'grade_levels',
      length: 5,
    })
    gradeLevels: number;

    @OneToOne(type => FcOptions)
    @JoinColumn({
      name: 'fk_highschool_id',
    })
    highschoolId: FcOptions;

    @OneToOne(type => FcUserdefinedDisplayTo, fcUserdefinedDisplayTo => fcUserdefinedDisplayTo.userdefinedId)
    displayTo: FcUserdefinedDisplayTo;
}
