import { Entity, Column, PrimaryColumn, JoinColumn, OneToOne } from 'typeorm';
import { HobsonsSchools } from './HobsonsSchoolModel';
import { HobsonsSchoolArea } from './HobsonsSchoolAreaModel';

@Entity()
export class College {
  @PrimaryColumn('string')
  id: string;

  @Column('int', {
    name: 'hobsons_id',
  })
  hobsonsId: number;

  @Column('string', {
    name: 'short_name',
  })
  shortName: string;

  @Column('string')
  city: string;

  @Column('string')
  state: string;

  @OneToOne(type => HobsonsSchools)
  @JoinColumn({
    name: 'hobsons_id',
  })
  school: HobsonsSchools;

  @OneToOne(type => HobsonsSchoolArea)
  @JoinColumn({
    name: 'hobsons_id',
  })
  schoolArea: HobsonsSchoolArea;
}
