import 'reflect-metadata';
import { QueryBuilder } from 'typeorm';

import { createTestApp, TestApp } from '../../mocks/mock-app';
import { BaseRepository } from './';

class TBaseRepository extends BaseRepository {
}

let app: TestApp;
let baseRepository: TBaseRepository;
let queryBuilder: QueryBuilder<any>;

beforeAll(async () => {
  app = await createTestApp();
  baseRepository = new TBaseRepository();
});

afterAll(() => {
  app.destroy();
});

beforeEach(() => {
  queryBuilder = new QueryBuilder<any>(app.connection);
  queryBuilder.fromTable('Table1', 't1');
});

describe('apply query pagination', () => {
  it('should add limit and offset to query', async () => {
    baseRepository.applyPagination(queryBuilder, 2, 10);

    // tslint:disable-next-line:no-string-literal
    expect(queryBuilder['limit']).toBe(10);
    // tslint:disable-next-line:no-string-literal
    expect(queryBuilder['offset']).toBe(10);
  });
});

describe('apply query filters', () => {
  it('should generate base query', async () => {
    expect(queryBuilder.getSql()).toBe('SELECT * FROM `Table1` `t1`');
  });

  it('should add where condition to query', async () => {
    baseRepository.applyFilter(queryBuilder, {
      'prop1': '10',
    }, ['prop1']);

    expect(queryBuilder.getSql()).toBe('SELECT * FROM `Table1` `t1` WHERE prop1 = ?');
  });

  it('should ignore not allowed filter properties', async () => {
    baseRepository.applyFilter(queryBuilder, {
      'prop1': '10',
      'prop2': '20',
    }, ['prop1']);

    expect(queryBuilder.getSql()).toBe('SELECT * FROM `Table1` `t1` WHERE prop1 = ?');
  });

  it('should combine same level filter properties with AND operator', async () => {
    baseRepository.applyFilter(queryBuilder, {
      'prop1': '10',
      'prop2': '20',
    }, ['prop1', 'prop2']);

    expect(queryBuilder.getSql()).toBe('SELECT * FROM `Table1` `t1` WHERE prop1 = ? AND prop2 = ?');
  });

  it('should join statements with AND operator', async () => {
    baseRepository.applyFilter(queryBuilder, {
      'AND': [
        { 'prop1': '10' },
        { 'prop2': '20' },
      ],
    }, ['prop1', 'prop2']);

    expect(queryBuilder.getSql()).toBe('SELECT * FROM `Table1` `t1` WHERE prop1 = ? AND prop2 = ?');
  });

  it('should join statements with OR operator', async () => {
    baseRepository.applyFilter(queryBuilder, {
      'OR': [
        { 'prop1': '10' },
        { 'prop2': '20' },
      ],
    }, ['prop1', 'prop2']);

    expect(queryBuilder.getSql()).toBe('SELECT * FROM `Table1` `t1` WHERE prop1 = ? OR prop2 = ?');
  });

  it('should check equality operators', async () => {
    baseRepository.applyFilter(queryBuilder, {
      'prop1': '= 10',
      'prop2': '> 20',
      'prop3': '>= 30',
      'prop4': '< 40',
      'prop5': '<= 50',
    }, ['prop1', 'prop2', 'prop3', 'prop4', 'prop5']);

    expect(queryBuilder.getSql()).toBe(
      'SELECT * FROM `Table1` `t1` WHERE prop1 = ? AND prop2 > ? AND prop3 >= ? AND prop4 < ? AND prop5 <= ?');
  });

  it('should check IN and IS operator', async () => {
    baseRepository.applyFilter(queryBuilder, {
      'prop1': 'IN [10,20]',
      'prop2': 'IS NULL',
      'prop3': 'IS NOT NULL',
    }, ['prop1', 'prop2', 'prop3']);

    expect(queryBuilder.getSql()).toBe('SELECT * FROM `Table1` `t1` WHERE prop1 IN (?) AND prop2 IS ? AND prop3 IS NOT ?');
  });

  it('should check LIKE operator', async () => {
    baseRepository.applyFilter(queryBuilder, {
      'prop1': 'LIKE %abc%',
    }, ['prop1']);

    expect(queryBuilder.getSql()).toBe('SELECT * FROM `Table1` `t1` WHERE prop1 LIKE ?');
  });
});

describe('paginate', () => {
  it('should return paginated result', async () => {
    const page = 1;
    const limit = 10;
    const len = 27;
    const getCount = () => {
      return new Promise<number>((resolve: Function) => {
        resolve(len);
      });
    };
    const getData = () => {
      return new Promise<any[]>((resolve: Function) => {
        const data: any[] = [];
        data.length = len;
        resolve(data);
      });
    };

    queryBuilder.getCount = getCount;

    const paginatedResult = await baseRepository.paginate(queryBuilder, getData(), page, limit);

    expect(paginatedResult).not.toBe(null);
    expect(paginatedResult.page).toBe(page);
    expect(paginatedResult.limit).toBe(limit);
    expect(paginatedResult.data).not.toBe(null);
    expect(paginatedResult.totalItems).toBe(len);
    expect(paginatedResult.totalPages).toBe(Math.ceil(len / limit));
  });
});
