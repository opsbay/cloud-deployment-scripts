import 'reflect-metadata';
import { Container } from 'typedi';

import { createTestApp, TestApp } from '../../mocks/mock-app';
import { LinkRepository } from './LinkRepository';

let app: TestApp;
let repo: LinkRepository;

beforeAll(async () => {
  app = await createTestApp();
  repo = Container.get(LinkRepository);
});

afterAll(() => {
  app.destroy();
});

describe('find', () => {
  it('should fetch all links', async () => {
    let response = await repo.find();
    expect(response.id).not.toBe(null);
    expect(response.name).not.toBe(null);
    expect(response.url).not.toBe(null);
  });

  it('should fetch all links with custom language', async () => {
    let response = await repo.find(null, 'pages');
    expect(response.id).not.toBe(null);
    expect(response.name).not.toBe(null);
    expect(response.html).not.toBe(null);
  });

  it('should fetch all pages', async () => {
    let response = await repo.find('ZH_CN', 'pages');
    expect(response.id).not.toBe(null);
    expect(response.name).not.toBe(null);
    expect(response.html).not.toBe(null);
  });
});

describe('findResourceLinks', () => {
  it('should fetch all resource links', async () => {
    let response = await repo.findResourceLinks();
    expect(response).not.toBe(null);
  });
});

describe('findMessageCount', () => {
  it('should fetch message count', async () => {
    let response = await repo.findMessageCount();
    expect(response).not.toBe(null);
  });
});

describe('findNewsLinks', () => {
  it('should fetch all news', async () => {
    let response = await repo.findNewsLinks();
    expect(response).not.toBe(null);
  });

  it('should fetch all news with custom language', async () => {
    let response = await repo.findNewsLinks('ZH_CN');
    expect(response).not.toBe(null);
  });
});
