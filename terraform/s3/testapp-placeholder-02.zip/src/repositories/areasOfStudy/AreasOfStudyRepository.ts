import { Service } from 'typedi';
import { Repository } from 'typeorm';
import { OrmRepository } from 'typeorm-typedi-extensions';

import { AreasOfStudy } from '../../models';
import { BaseRepository, PaginatedResult } from '../';

@Service()
export class AreasOfStudyRepository extends BaseRepository {
  constructor(@OrmRepository(AreasOfStudy) private repo: Repository<AreasOfStudy>) {
    super();
  }

  public search(filter?: any, page: number = 1, limit: number = 25): Promise<PaginatedResult<any>> {
    const builder = this.repo.createQueryBuilder('areasOfStudy');

    this.applyFilter(builder, filter, [
      'areasOfStudy.name',
    ]);
    this.applyPagination(builder, page, limit);

    builder.orderBy('areasOfStudy.name');

    return this.paginate(builder, builder.getMany(), page, limit);
  }
}
