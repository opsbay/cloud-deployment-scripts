export * from './AreasOfStudyRepository';
