import { Service } from 'typedi';
import { Repository } from 'typeorm';
import { OrmRepository } from 'typeorm-typedi-extensions';

import { Sports } from '../../models';
import { BaseRepository, PaginatedResult } from '../';

@Service()
export class SportsRepository extends BaseRepository {
  constructor(@OrmRepository(Sports) private repo: Repository<Sports>) {
    super();
  }

  public search(filter?: any, page: number = 1, limit: number = 25): Promise<PaginatedResult<any>> {
    const builder = this.repo.createQueryBuilder('sports');

    this.applyFilter(builder, filter, [
      'sports.name',
    ]);
    this.applyPagination(builder, page, limit);

    builder.orderBy('sports.name');

    return this.paginate(builder, builder.getMany(), page, limit);
  }
}
