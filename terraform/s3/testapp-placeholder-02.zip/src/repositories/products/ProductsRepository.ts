import { Service } from 'typedi';
import { Repository } from 'typeorm';
import { OrmRepository } from 'typeorm-typedi-extensions';

import { Product } from '../../models';
import { BaseRepository } from '../';

@Service()
export class ProductsRepository extends BaseRepository {
  constructor(@OrmRepository(Product) private repo: Repository<Product>) {
    super();
  }

  public getProductsByHighSchool(highSchoolId: string): Promise<any[]> {
    const sql = `SELECT p.id, p.name
                 FROM \`products\` p
                 INNER JOIN \`highschool_product\` hp ON p.id = hp.fk_product_id
                 WHERE hp.fk_highschool_id = ?
                 ORDER BY p.id`;

    return this.repo.query(sql, [highSchoolId])
      .then(res => {
        return res;
      });
  }
}
