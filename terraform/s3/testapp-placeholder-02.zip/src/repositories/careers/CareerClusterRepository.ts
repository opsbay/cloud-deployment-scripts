import { Service } from 'typedi';
import { Repository } from 'typeorm';
import { OrmRepository } from 'typeorm-typedi-extensions';

import { CareerCluster } from '../../models';
import { BaseRepository, PaginatedResult } from '../';

@Service()
export class CareerClusterRepository extends BaseRepository {
    constructor(@OrmRepository(CareerCluster) private repo: Repository<CareerCluster>) {
      super();
    }

    public search(filter?: any, page: number = 1, limit: number = 25): Promise<PaginatedResult<any>> {
      const builder = this.repo.createQueryBuilder('career_clusters');

      this.applyFilter(builder, filter, [
        'name',
      ]);
      this.applyPagination(builder, page, limit);
      builder.orderBy('name');
      return this.paginate(builder, builder.getMany(), page, limit);
    }
}
