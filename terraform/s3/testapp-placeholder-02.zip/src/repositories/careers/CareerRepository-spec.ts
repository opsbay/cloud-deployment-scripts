import 'reflect-metadata';
import { Container } from 'typedi';

import { createTestApp, TestApp } from '../../mocks/mock-app';
import { CareerRepository } from './CareerRepository';

let app: TestApp;
let repo: CareerRepository;

beforeAll(async () => {
  app = await createTestApp();
  repo = Container.get(CareerRepository);
});

afterAll(() => {
  app.destroy();
});

describe('search careers', () => {
  it('should provide careers filtered results', async () => {
    let response = await repo.search({
      'name': 'LIKE %%',
    });

    expect(response).not.toBe(null);
  });

  it('should provide careers paginated results', async () => {
    let response = await repo.search(null, 1, 10);

    expect(response).not.toBe(null);
    expect(response).toMatchObject({
      page: 1,
      limit: 10,
    });
  });

  it('should provide one career result', async () => {
    let response = await repo.search(null, 1, 1);

    expect(response).not.toBe(null);
    expect(response.data).not.toBe(null);
    expect(response.data).toHaveLength(1);
  });
});
