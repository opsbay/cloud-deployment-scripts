import 'reflect-metadata';
import { Container } from 'typedi';

import { createTestApp, TestApp } from '../../mocks/mock-app';
import { ReligiousAffiliationRepository } from './';

let app: TestApp;
let repo: ReligiousAffiliationRepository;

beforeAll(async () => {
  app = await createTestApp();
  repo = Container.get(ReligiousAffiliationRepository);
});

afterAll(() => {
  app.destroy();
});

describe('search', () => {
  it('should provide filtered results', async () => {
    let response = await repo.search({});

    expect(response).not.toBe(null);
  });

  it('should provide paginated results', async () => {
    let response = await repo.search(null, 1, 10);

    expect(response).not.toBe(null);
    expect(response).toMatchObject({
      page: 1,
      limit: 10,
    });
  });

  it('should provide one result', async () => {
    let response = await repo.search(null, 1, 1);

    expect(response).not.toBe(null);
    expect(response.data).not.toBe(null);
    expect(response.data).toHaveLength(1);
  });
});
