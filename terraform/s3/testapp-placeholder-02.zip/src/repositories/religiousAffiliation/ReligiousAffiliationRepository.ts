import { Service } from 'typedi';
import { Repository } from 'typeorm';
import { OrmRepository } from 'typeorm-typedi-extensions';

import { ReligiousAffiliation } from '../../models';
import { BaseRepository, PaginatedResult } from '../';

@Service()
export class ReligiousAffiliationRepository extends BaseRepository {
  constructor(@OrmRepository(ReligiousAffiliation) private repo: Repository<ReligiousAffiliation>) {
    super();
  }

  public search(filter?: any, page: number = 1, limit: number = 25): Promise<PaginatedResult<any>> {
    const builder = this.repo.createQueryBuilder('religiousAffiliation');

    this.applyFilter(builder, filter, [
      'religiousAffiliation.name',
    ]);
    this.applyPagination(builder, page, limit);

    builder.orderBy('religiousAffiliation.name');

    return this.paginate(builder, builder.getMany(), page, limit);
  }
}
