export * from './ReligiousAffiliationRepository';
