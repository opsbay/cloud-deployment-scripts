export * from './CollegeRepository';
