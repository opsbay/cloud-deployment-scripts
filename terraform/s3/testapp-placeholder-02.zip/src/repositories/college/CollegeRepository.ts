import { Service } from 'typedi';
import { Repository } from 'typeorm';
import { OrmRepository } from 'typeorm-typedi-extensions';

import { College } from '../../models';
import { BaseRepository, PaginatedResult } from '../';

@Service()
export class CollegeRepository extends BaseRepository {
  constructor(@OrmRepository(College) private repo: Repository<College>) {
    super();
  }

  public search(filter?: any, page: number = 1, limit: number = 25): Promise<PaginatedResult<any>> {
    const builder = this.repo.createQueryBuilder('college')
      .innerJoinAndSelect('college.school', 'school')
      .leftJoinAndSelect('college.schoolArea', 'schoolArea');

    this.applyFilter(builder, filter, [
      'college.state',
      'college.geo_region',
      'school.city_size',
      'school.search_school_type',
      'school.search_school_control',
      'school.search_coed_status',
      'school.search_total_undergrad_enrollment',
      'school.search_percent_minority',
      'school.percent_out_of_state',
      'school.search_male_female_ratio',
      'school.search_percent_accepted',
      'school.undergrad_in_state_tuition',
      'school.undergrad_out_state_tuition',
      'schoolArea.area_id',
    ]);
    this.applyPagination(builder, page, limit);

    builder.orderBy('college.shortName');

    return this.paginate(builder, builder.getMany(), page, limit);
  }
}
