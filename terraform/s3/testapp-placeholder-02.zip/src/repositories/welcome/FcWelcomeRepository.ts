import { Service } from 'typedi';
import { Repository } from 'typeorm';
import { OrmRepository } from 'typeorm-typedi-extensions';

import { FcWelcome } from '../../models';
import { BaseRepository } from '../';

@Service()
export class FcWelcomeRepository extends BaseRepository {
  constructor(@OrmRepository(FcWelcome) private repo: Repository<FcWelcome>) {
    super();
  }

  public find(lang?: any): Promise<FcWelcome> {
    // //TO-DO have to fetch from respetive classes
    const currentUser = {
      isGuest: false,
      grade: 12,
      schoolId: '88881USPU',
    };

    const findOptions = <any>{
      alias: 'fc_welcome',
      whereConditions: {
        fk_highschool_id: currentUser.schoolId,
      },
    };

    if(lang) {
      findOptions.leftJoinAndSelect = {
          translation: 'fc_welcome.translation',
        };
      findOptions.whereConditions['translation.fk_language_id'] = lang;
    }

    if(currentUser.isGuest) {
      findOptions.whereConditions.for_guests = currentUser.isGuest;
    }

    if(currentUser.grade) {
      findOptions.where = `(grade_levels & pow(2,:gradeLevels))`;
      findOptions.parameters = {
        gradeLevels: currentUser.grade,
      };
    }

    return this.repo.findOne(findOptions)
      .then((res)=> {
        const respObj = {
          title: '', //to-do move to config or constants file
          welcome: 'No Welcome Message is available at this time.',
        };
        if(res) {
          if(res.translation) {
            const translation = res.translation;
            respObj.title = translation.title;
            respObj.welcome = translation.welcome;
            return respObj;
          }
          respObj.title = res.title;
          respObj.welcome = res.welcome;
          return respObj;
        }
        return respObj;
      });
  }

}
