import * as http from 'http';
import * as os from 'os';
import * as path from 'path';
import * as bodyParser from 'body-parser';
import * as cluster from 'cluster';
import * as compression from 'compression';
import * as config from 'config';
import * as cookieParser from 'cookie-parser';
import * as cors from 'cors';
import * as express from 'express';
import * as morgan from 'morgan';
import 'reflect-metadata';
import { ConnectionManager } from '../services';
import { logger, skip, stream } from '../utils';
import { Worker } from 'cluster';
import { Express } from 'express';
import { MicroframeworkSettings } from 'microframework';
import { useExpressServer } from 'routing-controllers';
import { Inject } from 'typedi';

interface ServerAddress {
  address: string;
  port: number;
  addressType: string;
}

export class Server {
  private _app: Express;
  private _server: http.Server;

  @Inject()
  connectionManager: ConnectionManager;

  constructor() {
    this._app = express();
    this._app.use(cors());
    this._app.use(compression());
    this._app.use(bodyParser.json());
    this._app.use(bodyParser.text());
    this._app.use(cookieParser());
    this._app.use(express.static(path.join(__dirname, './../public')));
    this._app.use(morgan('combined', { skip: skip, stream: <any>stream }));

    useExpressServer(this._app, {
      controllers: [
        __dirname + './../controllers/!(*-spec).*s',
      ],
    });

    this._server = http.createServer(this._app);
  }

  private _onListening(): void {
    const address = this._server.address();
    const bind = `port ${address.port}`;

    logger.info(`Listening on ${bind}.`);
  }

  getServer(): http.Server {
    return this._server;
  }

  start(): void {
    if (cluster.isMaster && config.get('server.env') === 'prod') {
      for (let c = 0; c < os.cpus().length; c++) {
        cluster.fork();
      }

      cluster.on('exit', (worker: Worker, code: number, signal: string) => {
        logger.info(`Worker ${worker.process.pid} died.`);
      });

      cluster.on('listening', (worker: Worker, address: ServerAddress) => {
        logger.info(`Worker ${worker.process.pid} connected to port ${address.port}.`);
      });
    } else {
      this._server.listen(config.get('server.port'));
      this._server.on('listening', () => this._onListening());
    }
  }

  stop(): void {
    this._server.close();
    process.exit(0);
  }
}

export async function expressModule(settings: MicroframeworkSettings): Promise<Server> {
  const server = new Server();

  server.start();
  settings.onShutdown(() => server.stop());

  return server;
}
