import { expressModule, typeOrmModule } from './modules';
import { logger } from './utils';
import * as config from 'config';
import { bootstrapMicroframework } from 'microframework';

bootstrapMicroframework({
  config: config.get('framework'),
  modules: [
    expressModule,
    typeOrmModule,
  ],
})
  .then(() => logger.info('Application is up and running.'))
  .catch(error => logger.info('Application has crashed: ' + error));
