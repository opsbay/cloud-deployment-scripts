import * as models from '../models';
import * as config from 'config';
import { values } from 'lodash';
import { Service } from 'typedi';
import { Connection, createConnection, DriverOptions } from 'typeorm';

@Service()
export class ConnectionManager {
  public createConnection(): Promise<Connection> {
    return createConnection({
      driver: config.get('database') as DriverOptions,
      entities: [
        ...values<Function>(models),
      ],
      logging: {
        logQueries: config.get('logging.queries') as boolean,
      },
    });
  }
}
