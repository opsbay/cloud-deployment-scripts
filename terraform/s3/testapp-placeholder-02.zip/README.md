# mobile-responsive-family-connection-app
Built from [generator-naviance-node](https://github.com/naviance/generator-naviance-node)

## Installation and use
You may install dependencies with npm or yarn. Check the package.json for scripts.

## Running on Docker
Follow instructions here: [https://confluence.hobsons.com/display/NH/Prebuilt+and+custom+images](https://confluence.hobsons.com/display/NH/Prebuilt+and+custom+images)
### Service + Database
`docker-compose up -d` builds and starts everything
`docker-compose stop` to stop (can be started with `up` or `start`).
`docker-compose down` to stop all containers and remove them.
### Database only
`docker-compose up -d mysql`
### Run tests
`docker-compose run --rm fc-api npm test`

## Swagger
Swagger will automatically document all routing-controllers apis and publish them to [http://localhost:8080/api-docs.json](http://localhost:8080/api-docs.json). You can override the spec in yaml config.

Run swagger-ui with `docker-compose -f docker-compose-swagger-ui.yml up -d` and browse your spec at [http://localhost:3333/?api_url=http://localhost:8080/api-docs.json#/default](http://localhost:3333/?api_url=http://localhost:8080/api-docs.json#/default).
### Limitations
* Routing-controllers does not support comments so the description fields will be blank.
* Swagger-ui 3+ has a bug that breaks cors so using 2.2.9 for now.
* Actual TypeScript types are expressed while the UI only expects primitives so swagger-ui will fall back to expecting strings.
