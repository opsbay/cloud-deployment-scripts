import { Entity, Column, PrimaryColumn } from 'typeorm';

@Entity()
export class HobsonsSchoolArea {
  @PrimaryColumn('int', {
    name: 'hobsons_id',
  })
  hobsonsId: number;

  @Column('int', {
    name: 'area_id',
  })
  areaId: number;
}
