import { Entity, Column, PrimaryColumn } from 'typeorm';

@Entity('hobsons_sports')
export class Sports {
  @PrimaryColumn('string', {
    name: 'hobsons_id',
  })
  id: string;

  @Column('string')
  name: string;
}
