import {Entity, Column, PrimaryColumn} from 'typeorm';

@Entity('career_clusters')
export class CareerCluster {
  @PrimaryColumn('int')
  id: number;

  @Column('string', {
    length: 100,
  })
  name: string;

  @Column('text')
  overview: string;

  @Column('text', {
    name: 'employment_outlook',
  })
  employmentOutlook: string;

  @Column('string', {
    length: 54,
    name: 'logo_file_name',
  })
  logo: string;

  @Column('string', {
    length: 128,
    name: 'planofstudy_file_name',
  })
  planOfStudyFile: string;
}
