import { Entity, PrimaryColumn, Column } from 'typeorm';

@Entity()
export class CourseSubjectArea {

    @PrimaryColumn('int')
    id: number;

    @Column('string', {
      length: 40,
    })
    name: string;

    @Column('smallint')
    status: number;

    @Column('string', {
      length: 6,
    })
    abbrev: string;

    @Column('smallint', {
      name: 'federal_code',
    })
    federalCode: number;

    @Column('float', {
      name: 'term_required_credits',
    })
    termRequiredCredits: number;

    @Column('float', {
      name: 'total_required_credits',
    })
    totalRequiredCredits: number;

    @Column('float', {
      name: 'required_credits_6',
    })
    requiredCredits6: number;

    @Column('float', {
      name: 'required_credits_7',
    })
    requiredCredits7: number;

    @Column('float', {
      name: 'required_credits_8',
    })
    requiredCredits8: number;

    @Column('float', {
      name: 'required_credits_9',
    })
    requiredCredits9: number;

    @Column('float', {
      name: 'required_credits_10',
    })
    requiredCredits10: number;

    @Column('float', {
      name: 'required_credits_11',
    })
    requiredCredits11: number;

    @Column('float', {
      name: 'required_credits_12',
    })
    requiredCredits12: number;

    @Column('string', {
      name: 'internal_state',
      default: 'normal',
    })
    internalState: string;
}
