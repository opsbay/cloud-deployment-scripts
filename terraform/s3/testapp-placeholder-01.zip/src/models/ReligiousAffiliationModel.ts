import {Entity, PrimaryColumn, Column} from 'typeorm';

@Entity()
export class ReligiousAffiliation {

    @PrimaryColumn('int')
    id: number;

    @Column({
        length: 35,
    })
    name: string;
}
