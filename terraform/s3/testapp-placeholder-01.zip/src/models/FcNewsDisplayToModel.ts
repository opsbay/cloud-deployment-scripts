import {Entity, PrimaryColumn, OneToOne, JoinColumn } from 'typeorm';

import { FcNews } from './FcNewsModel';
@Entity()
export class FcNewsDisplayTo {

    @PrimaryColumn({
      name: 'fk_language_id',
    })
    languageId: string;

    @OneToOne(type => FcNews)
    @JoinColumn({
      name: 'fk_fc_news_id',
    })
    newsId: FcNews;
}
