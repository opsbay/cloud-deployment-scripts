import { Entity, Column, OneToOne, JoinColumn, PrimaryColumn } from 'typeorm';

import { FcWelcome } from './FcWelcomeModel';

@Entity()
export class FcWelcomeTranslations {

  @PrimaryColumn('string', {
    name: 'fk_language_id',
    length: 5,
  })
  languageId: string;

  @Column('string', {
    name: 'label',
    length: 255,
  })
  title: string;

  @Column('text', {
    name: 'welcome_html',
  })
  welcome: string;

  @OneToOne(type => FcWelcome, welcomeId => welcomeId.id)
  @JoinColumn({
    name: 'fk_fc_welcome_id',
  })
  welcomeId: FcWelcome;

}
