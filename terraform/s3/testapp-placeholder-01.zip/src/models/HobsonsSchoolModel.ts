import { Entity, Column, PrimaryColumn } from 'typeorm';

@Entity()
export class HobsonsSchools {
  @PrimaryColumn('int', {
    name: 'hobsons_id',
  })
  hobsonsId: number;

  @Column('int', {
    name: 'city_size',
  })
  citySize: number;
}
