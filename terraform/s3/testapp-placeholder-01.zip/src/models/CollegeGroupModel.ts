import { Entity, Column, PrimaryColumn } from 'typeorm';

@Entity('hs_college_group')
export class CollegeGroup {
  @PrimaryColumn('string')
  id: string;

  @Column('string')
  name: string;
}
