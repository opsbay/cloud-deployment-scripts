import { Entity, Column, JoinColumn, OneToOne, PrimaryColumn } from 'typeorm';
import { Expose } from 'class-transformer';

import { CourseSubjectArea } from './CourseSubjectAreaModel';

@Entity()
export class Course {

    @PrimaryColumn('int')
    id: number;

    @Column('string', {
      length: 12,
      name: 'fk_highschool_id',
    })
    highschoolId: string;

    @Column('string', {
      length: 20,
      name: 'school_code',
    })
    schoolCode: string;

    @Column('string', {
      length: 20,
      name: 'district_code',
    })
    districtCode: string;

    @Column('string', {
      length: 20,
      name: 'state_code',
    })
    stateCode: string;

    @Column('int', {
      name: 'subject_area',
    })
    @OneToOne(type => CourseSubjectArea, subjectArea => subjectArea.id)
    @JoinColumn({
      name: 'subject_area',
    })
    subjectArea: CourseSubjectArea;

    @Column('int', {
      name: 'fk_import_id',
    })
    fkImportId: number;

    @Column('string', {
      length: 80,
    })
    title: string;

    @Column('text')
    description: string;

    @Column('text')
    prerequisites: string;

    @Column('smallint', {
      name: 'permission_required',
    })
    permissionRequired: number;

    @Column('smallint', {
      name:'audition_required',
    })
    auditionRequired: string;

    @Column('string', {
      length: 250,
      name: 'audition_details',
    })
    auditionDetails: string;

    @Column('smallint',{
      name: 'summer_prep_required',
    })
    summerPrepRequired: number;

    @Column('string', {
      length: 250,
      name: 'summer_prep_details',
    })
    summerPrepDetails: string;

    @Column('smallint', {
      name: 'fee_required',
    })
    feeRequired: number;

    @Column('string', {
      length: 150,
      name: 'fee_details',
    })
    feeDetails: string;

    @Column('string', {
      length: 2,
      name: 'instructional_level',
    })
    instructionalLevel: string;

    @Column('float')
    credits: number;

    @Column('string', {
      length: 2,
      name: 'credit_type',
    })
    creditType: string;

    @Column('smallint', {
      name: 'is_grad_requirement',
    })
    isGradRequirement: number;

    @Column('smallint', {
      name: 'is_repeatable',
    })
    isRepeatable: number;

    @Column('smallint', {
      name: 'is_state_core',
    })
    isStateCore: number;

    @Column('smallint', {
      name: 'use_in_gpa',
    })
    useInGpa: number;

    @Column('smallint', {
      name: 'ncaa_core_eligible',
    })
    ncaaCoreEligible: number;

    @Column('smallint', {
      default: 0,
    })
    grade6: number;

    @Column('smallint', {
      default: 0,
    })
    grade7: number;

    @Column('smallint', {
      default: 0,
    })
    grade8: number;

    @Column('smallint', {
      default: 0,
    })
    grade9: number;

    @Column('smallint', {
      default: 0,
    })
    grade10: number;

    @Column('smallint', {
      default: 0,
    })
    grade11: number;

    @Column('smallint', {
      default: 0,
    })
    grade12: number;

    @Column('smallint', {
      name: 'is_active',
      default: 1,
    })
    isActive: number;

    @Column('smallint', {
      name: 'last_year_active',
    })
    lastYearActive: number;

    @Column('bigint', {
      name: 'migration_tag',
    })
    migrationTag: number;

    @Column('datetime', {
      name: 'system_modified',
    })
    systemModified: Date;

    @Column('int', {
      name: 'last_modified_by',
    })
    lastModifiedBy: number;

    @Column('smallint')
    type: number;

    @Column('smallint', {
      name: 'is_tech_prep',
    })
    isTechPrep: number;

    @Column('string', {
      name: 'internal_state',
      default: 'normal',
    })
    internalState: string;

    @Expose()
    public get gradeLevels(): Array<any> {
      const grades = [this.grade6, this.grade7, this.grade8, this.grade9,
        this.grade10, this.grade11, this.grade12];
      return [6, 7, 8, 9, 10, 11, 12].filter((n: number, i: number) => {
        return grades[i];
      });
    }
}
