import { Service } from 'typedi';
import { Repository } from 'typeorm';
import { OrmRepository } from 'typeorm-typedi-extensions';

import { FcUserdefined } from '../../models';
import { FcNews } from '../../models';
import { BaseRepository } from '../';

export class Link {
  constructor(public name: string, public url: string, public icon: string = 'default') {}
}

@Service()
export class LinkRepository extends BaseRepository {
  private currentUser: any;

  constructor(@OrmRepository(FcUserdefined) private linkRepo: Repository<FcUserdefined>,
              @OrmRepository(FcNews) private newsRepo: Repository<FcNews>) {
    super();
    this.currentUser = {
      isGuest: false,
      grade: 12,
      schoolId: '88881USPU',
      role: 'student',
    };
  }

  public find(lang?: any, customType?: any): Promise<FcUserdefined> {
    // //TO-DO have to fetch from respetive classes
    const currentUser = this.currentUser;

    const findOptions = <any>{
      alias: 'fc_userdefined',
      where: 'url is not null',
      whereConditions: {
        fk_highschool_id: currentUser.schoolId,
      },
      leftJoinAndSelect: {
        displayTo: 'fc_userdefined.displayTo',
      },
      orderBy: {
        'fc_userdefined.displayOrder' : 'DESC',
       },
    };

    if(currentUser.isGuest) {
      currentUser.grade = 14;
    }

    if(lang) {
      findOptions.whereConditions = {
        'displayTo.fk_language_id': lang,
      };
    }

    if(customType === 'pages') {
      findOptions.where = 'url is null';
    }

    if(currentUser.grade) {
      findOptions.where = `${findOptions.where} AND (grade_levels & pow(2,:gradeLevels))`;
      findOptions.parameters = {
        gradeLevels: currentUser.grade,
      };
    }

    return this.linkRepo.find(findOptions)
      .then((res)=> {

        if(customType && customType === 'pages') {
          return res.map((link) => {
            return {
              id: link.id,
              name: link.name,
              html: link.html,
            };
          });
        }
        return res.map((link) => {
          return {
            id: link.id,
            name: link.name,
            url: link.url,
          };
        });

      })
      .catch(err=> {
        return err;
      });
  }

  public findResourceLinks(): Promise<any> {

    //To-do : have a Service status checking class globally.
    const activeServices = {
      SERVICE_OPS_CURRICULUM_ROSTERS_SSO: true, //'curriculum.rosters'
      SERVICE_OPS_TESTPREP_SSO: true, //'ops.testprep.sso'
    };

    const resourcelinks: any[] = [];

    if(activeServices.SERVICE_OPS_CURRICULUM_ROSTERS_SSO) {
      const url = '#';
      resourcelinks.push({
        type: 'curriculumLink',
        url: url,
      });
    }

    if(activeServices.SERVICE_OPS_TESTPREP_SSO) {
      const url = '#'; //to-do this link is likely to be generated from server.
      resourcelinks.push({
        type: 'navianceTestPrep',
        url: url,
      });
    }

    return new Promise<any>((resolve: Function) => {
      return resolve(resourcelinks);
    });
  }

  public findMessageCount(): Promise<any> {

    //Todo - should come from communication class - getFamilyConnectionMessages
    const messageCount = 0;

    return new Promise<any>((resolve: Function) => {
      return resolve({
        messageCount: messageCount,
      });
    });
  }

  public findNewsLinks(lang?: any): Promise<any> {
    // // //TO-DO have to fetch from respetive classes
    const currentUser = this.currentUser;

    const builder = this.newsRepo.createQueryBuilder('fc_news')
      // .select([
      //   'id',
      //   'headline as name',
      //   'news_html as html',
      // ])
      .addSelect([
        'if(start_date > 0, start_date, 0) as start_date',
        'if(date_created > 0, date_created, 0) as date_created',
        'if(start_date > 0, start_date, date_created) as sort_date',
      ])
      .leftJoinAndSelect('fc_news.displayTo', 'displayTo')
      .orderBy('sort_date', 'DESC');

    const filter = <any> {
      fk_highschool_id: currentUser.schoolId,
    };

    if(lang) {
     filter.fk_language_id = lang;
    }

    if(currentUser.isGuest) {
     filter.for_guests = currentUser.isGuest;
    }

    if(currentUser.grade) {
     builder.andWhere('(grade_levels & pow(2,:gradeLevels))');
     builder.addParameters({
       gradeLevels: currentUser.grade,
     });
    }

    this.applyFilter(builder, filter, [
      'fk_highschool_id',
      'fk_language_id',
    ]);

    return builder.getMany().then((res)=> {

      return res.map((newsItem) => {
        return {
          id: newsItem.id,
          title: newsItem.headline,
          html: newsItem.news,
        };
      });

    })
    .catch(err=> {
      return err;
    });
  }
}
