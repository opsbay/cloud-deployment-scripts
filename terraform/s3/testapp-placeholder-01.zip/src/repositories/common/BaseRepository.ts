import { QueryBuilder } from 'typeorm';

export class PaginatedResult<T> {
  page: number;
  limit: number;
  totalPages: number;
  totalItems: number;
  data: T[];
}

export abstract class BaseRepository {
  private allowedOperators: string[] = [
    '=', '>', '>=', '<', '<=', 'IN', 'IS', 'LIKE',
  ];

  public paginate<T>(builder: QueryBuilder<any>, resultsPromise: Promise<T[]>, page: number, limit: number): Promise<PaginatedResult<T>> {
    const paginatedResults = new PaginatedResult<T>();

    paginatedResults.page = page;
    paginatedResults.limit = limit;

    return resultsPromise
      .then(results => {
        paginatedResults.data = results;

        return builder.getCount()
          .then(totalItems => {
            paginatedResults.totalItems = totalItems;
            paginatedResults.totalPages = Math.ceil(totalItems / limit);

            return paginatedResults;
          });
      });
  }

  public applyPagination(builder: QueryBuilder<any>, page: number, limit: number) {
    builder.setOffset((page - 1) * limit);
    builder.setLimit(limit);
  }

  public applyFilter(builder: QueryBuilder<any>, filter: any, allowedList: string[], operator: string = 'AND') {
    if (filter) {
      if ('AND' in filter) {
        this.applyFilterBlock(builder, filter, allowedList, 'AND');
      } else if ('OR' in filter) {
        this.applyFilterBlock(builder, filter, allowedList, 'OR');
      } else {
        this.applyFilterItem(builder, filter, allowedList, operator);
      }
    }
  }

  private applyFilterBlock(builder: QueryBuilder<any>, filter: any, allowedList: string[], operator: string) {
    const block = filter[operator];

    if (Array.isArray(block) && block.length > 1) {
      block.forEach((item: any) => {
        this.applyFilter(builder, item, allowedList, operator);
      });
    }
  }

  private applyFilterItem(builder: QueryBuilder<any>, item: any, allowedList: string[] = [], operator: string) {
    if (!item) {
      return;
    }

    Object.keys(item)
      .forEach(key => {
        if (allowedList.indexOf(key) === -1) {
          return;
        }

        let value = item[key];

        if (!value) {
          return;
        }

        value = value.trim();
        const parts = value.split(' ', 3);

        if (parts.length === 0) {
          return;
        }

        if (parts.length === 1) {
          parts.unshift('=');
        }

        let op = parts.shift().toUpperCase();

        if (this.allowedOperators.indexOf(op) === -1) {
          return;
        }

        const rnd = Math.random();

        let val = parts.shift();
        let expr;

        if (op === 'IN') {
          expr = `${key} ${op} (:value__${rnd})`;

          try {
            val = JSON.parse(val);
          } catch (e) {
            return;
          }
        } else if (op === 'IS') {
          if (val === 'NOT') {
            op = 'IS NOT';
            val = parts.shift();
          }
        }

        if (val === 'NULL') {
          val = null;
        }

        if (!expr) {
          expr = `${key} ${op} :value__${rnd}`;
        }

        const action = (operator !== 'OR') ? builder.andWhere : builder.orWhere;

        action.call(builder, expr, {
          [`value__${rnd}`]: val,
        });
      });
  }
}
