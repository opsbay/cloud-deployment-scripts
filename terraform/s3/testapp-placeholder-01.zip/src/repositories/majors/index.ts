export * from './MajorsRepository';
