import { Service } from 'typedi';
import { Repository } from 'typeorm';
import { OrmRepository } from 'typeorm-typedi-extensions';

import { Majors } from '../../models';
import { BaseRepository, PaginatedResult } from '../';

@Service()
export class MajorsRepository extends BaseRepository {
  constructor(@OrmRepository(Majors) private repo: Repository<Majors>) {
    super();
  }

  public search(filter?: any, page: number = 1, limit: number = 25): Promise<PaginatedResult<any>> {
    const builder = this.repo.createQueryBuilder('majors');

    this.applyFilter(builder, filter, [
      'majors.name',
      'majors.area_of_study_id',
    ]);
    this.applyPagination(builder, page, limit);

    builder.orderBy('majors.name');

    return this.paginate(builder, builder.getMany(), page, limit);
  }
}
