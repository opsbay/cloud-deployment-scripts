import { Service } from 'typedi';
import { Repository } from 'typeorm';
import { OrmRepository } from 'typeorm-typedi-extensions';

import { Career } from '../../models';
import { BaseRepository, PaginatedResult } from '../';

@Service()
export class CareerRepository extends BaseRepository {
    constructor(@OrmRepository(Career) private repo: Repository<Career>) {
      super();
    }

    public search(filter?: any, page: number = 1, limit: number = 25): Promise<PaginatedResult<any>> {
      const builder = this.repo.createQueryBuilder('career_clusters');

      this.applyFilter(builder, filter, [
        'title',
      ]);
      this.applyPagination(builder, page, limit);
      builder.orderBy('title');
      return this.paginate(builder, builder.getMany(), page, limit);
    }
}
