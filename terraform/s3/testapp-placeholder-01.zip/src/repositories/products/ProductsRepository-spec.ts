import 'reflect-metadata';
import { Container } from 'typedi';

import { createTestApp, TestApp } from '../../mocks/mock-app';
import { ProductsRepository } from './';

let app: TestApp;
let repo: ProductsRepository;

beforeAll(async () => {
  app = await createTestApp();
  repo = Container.get(ProductsRepository);
});

afterAll(() => {
  app.destroy();
});

describe('get by highSchool', () => {
  it('should provide results', async () => {
    let response = await repo.getProductsByHighSchool('88801USPU');

    expect(response).not.toBe(null);
  });
});
