import 'reflect-metadata';
import { Container } from 'typedi';

import { createTestApp, TestApp } from '../../mocks/mock-app';
import { FcWelcomeRepository } from './FcWelcomeRepository';

let app: TestApp;
let fcWelcomeRepository: FcWelcomeRepository;

beforeAll(async () => {
  app = await createTestApp();
  fcWelcomeRepository = Container.get(FcWelcomeRepository);
});

afterAll(() => {
  app.destroy();
});

describe('welcome', () => {
  it('should return welcome message without any language option', async () => {
    let response = await fcWelcomeRepository.find();
    expect(response.title).not.toBe(null);
    expect(response.welcome).not.toBe(null);
  });

  it('should return welcome message with a language option', async () => {
    let response = await fcWelcomeRepository.find('ZH_CN');
    expect(response.title).not.toBe(null);
    expect(response.welcome).not.toBe(null);
  });

  it('should return placeholder text for empty results', async () => {
    let response = await fcWelcomeRepository.find('FR');
    expect(response.title).toBe('');
    expect(response.welcome).toBe('No Welcome Message is available at this time.');
  });

});
