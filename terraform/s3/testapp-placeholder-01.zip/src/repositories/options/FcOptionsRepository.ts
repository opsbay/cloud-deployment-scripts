import { Service } from 'typedi';
import { Repository } from 'typeorm';
import { OrmRepository } from 'typeorm-typedi-extensions';

import { FcOptions } from '../../models/FcOptionsModel';
import { BaseRepository } from '../';

@Service()
export class FcOptionsRepository extends BaseRepository {
  constructor(@OrmRepository(FcOptions) private repo: Repository<FcOptions>) {
    super();
  }

  public getHighSchoolOptions(): Promise<FcOptions> {
    const sql = 'SELECT * FROM `fc_options` fco WHERE fco.`fk_highschool_id` = ?';

    // TODO: Should provide `fk_highschool_id` from current authenticated session
    return this.repo.query(sql, ['88801USPU'])
      .then(res => {
        return res[0];
      });
  }
}
