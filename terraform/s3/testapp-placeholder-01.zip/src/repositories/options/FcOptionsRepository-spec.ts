import 'reflect-metadata';
import { Container } from 'typedi';

import { createTestApp, TestApp } from '../../mocks/mock-app';
import { FcOptionsRepository } from './';

let app: TestApp;
let repo: FcOptionsRepository;

beforeAll(async () => {
  app = await createTestApp();
  repo = Container.get(FcOptionsRepository);
});

afterAll(() => {
  app.destroy();
});

describe('highschool options', () => {
  it('should provide highschool options', async () => {
    let response = await repo.getHighSchoolOptions();

    expect(response).not.toBe(null);
  });
});
