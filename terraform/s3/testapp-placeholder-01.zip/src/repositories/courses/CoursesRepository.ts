import { Container, Service } from 'typedi';
import { Repository, useContainer } from 'typeorm';
import { OrmRepository } from 'typeorm-typedi-extensions';

import { Course } from '../../models';
import {  BaseRepository, PaginatedResult } from '../';

useContainer(Container);

@Service()
export class CoursesRepository extends BaseRepository {
    constructor(@OrmRepository(Course) private repo: Repository<Course>) {
      super();
    }

    public search(filter?: any, page: number = 1, limit: number = 25): Promise<PaginatedResult<any>> {
      const filterObj = filter || {};
      const builder = this.repo.createQueryBuilder('course')
        .leftJoinAndSelect('course.subjectArea', 'subjectArea');

      // TODO: Should provide `fk_highschool_id` from current authenticated session
      // filterObj['course.fk_highschool_id'] = '88801USPU';
      filterObj['course.is_active'] = '= 1';

      this.applyFilter(builder, filterObj, [
        'course.fk_highschool_id',
        'title',
        'course.is_active',
      ]);
      this.applyPagination(builder, page, limit);
      builder.orderBy('course.title');
      return this.paginate(builder, builder.getMany(), page, limit);
  }
}
