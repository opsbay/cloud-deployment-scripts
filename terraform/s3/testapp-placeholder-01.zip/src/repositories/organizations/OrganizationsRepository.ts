import { Service } from 'typedi';
import { Repository } from 'typeorm';
import { OrmRepository } from 'typeorm-typedi-extensions';

import { HobsonsOrganizations } from '../../models';
import { BaseRepository, PaginatedResult } from '../';

@Service()
export class OrganizationsRepository extends BaseRepository {
  constructor(@OrmRepository(HobsonsOrganizations) private repo: Repository<HobsonsOrganizations>) {
    super();
  }

  public search(filter?: any, page: number = 1, limit: number = 25): Promise<PaginatedResult<any>> {
    const builder = this.repo.createQueryBuilder('organizations');

    this.applyFilter(builder, filter, [
      'organizations.name',
    ]);
    this.applyPagination(builder, page, limit);

    builder.orderBy('organizations.name');

    return this.paginate(builder, builder.getMany(), page, limit);
  }
}
