import { Service } from 'typedi';
import { Repository } from 'typeorm';
import { OrmRepository } from 'typeorm-typedi-extensions';

import { CollegeGroup } from '../../models';
import { BaseRepository, PaginatedResult } from '../';

@Service()
export class CollegeGroupRepository extends BaseRepository {
  constructor(@OrmRepository(CollegeGroup) private repo: Repository<CollegeGroup>) {
    super();
  }

  public search(filter?: any, page: number = 1, limit: number = 25): Promise<PaginatedResult<any>> {
    const builder = this.repo.createQueryBuilder('collegeGroup');

    this.applyFilter(builder, filter, [
      'collegeGroup.name',
    ]);
    this.applyPagination(builder, page, limit);

    builder.orderBy('collegeGroup.name');

    return this.paginate(builder, builder.getMany(), page, limit);
  }
}
