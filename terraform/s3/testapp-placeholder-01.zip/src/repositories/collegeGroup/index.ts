export * from './CollegeGroupRepository';
