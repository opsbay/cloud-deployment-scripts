import 'reflect-metadata';
import { Container } from 'typedi';
import { Connection, useContainer } from 'typeorm';
import { MicroframeworkSettings } from 'microframework';

import { ConnectionManager } from '../services';

useContainer(Container);

export async function typeOrmModule(settings: MicroframeworkSettings): Promise<Connection> {
  const connectionManager = new ConnectionManager();

  try {
    return await connectionManager.createConnection();
  } catch (e) {
    throw e;
  }
}
