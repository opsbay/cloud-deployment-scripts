import { Connection } from 'typeorm';
import { MicroframeworkSettings } from 'microframework';

import { expressModule, typeOrmModule, Server } from '../modules';

let microframeworkSettings = new MicroframeworkSettings();

export class TestApp {
  constructor(public server: Server,
              public connection: Connection) {
  }

  public destroy(): void {
    this.getServer().close();
    this.connection.close();
  }

  public getServer(): any {
    return this.server.getServer();
  }
}

export async function createTestApp(): Promise<TestApp> {
  return new TestApp(
    await expressModule(microframeworkSettings),
    await typeOrmModule(microframeworkSettings),
  );
}
