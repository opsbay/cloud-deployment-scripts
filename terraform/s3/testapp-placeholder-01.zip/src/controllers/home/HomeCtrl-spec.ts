import 'reflect-metadata';
import { createTestApp, TestApp } from '../../mocks/mock-app';
import { HomeController } from './HomeCtrl';
import * as request from 'supertest';

let homeController: HomeController;
let app: TestApp;
const placeHolderText: string = 'No Welcome Message is available at this time.';

beforeAll(async () => {
  app = await createTestApp();
  homeController = new HomeController();
});

afterAll(() => {
  app.destroy();
});

describe('HomeController.ts get WelcomeMessage method call', () => {
  it('should provide a response', async () => {
    const response = await homeController.getWelcomeMessage();
    expect(response.title).not.toBe(null);
    expect(response.welcome).not.toBe(null);
  });

  it('should accept language parameter', async () => {
    const response = await homeController.getWelcomeMessage('CN');
    expect(response.title).not.toBe(null);
    expect(response.welcome).not.toBe(null);
  });

  it('should show placeholder message', async () => {
    const response = await homeController.getWelcomeMessage('FR');
    expect(response.title).toBe('');
    expect(response.welcome).toBe(placeHolderText);
  });

});

describe('HomeController.ts get Welcome message http request', () => {
  it('should make a GET request', async () => {
    const response = await request(app.getServer()).get('/home/welcome');
    expect(response.status).toBe(200);
    expect(response.body.title).not.toBe(null);
    expect(response.body.welcome).not.toBe(null);
  });

  it('should make a GET request with language param', async () => {
    const response = await request(app.getServer()).get('/home/welcome?lang=fr');
    expect(response.status).toBe(200);
    expect(response.body.title).not.toBe(null);
    expect(response.body.welcome).not.toBe(null);
  });

  it('should make a GET request and respond placeholderText', async () => {
    const response = await request(app.getServer()).get('/home/welcome?lang=cn');
    expect(response.status).toBe(200);
    expect(response.body.title).toBe('');
    expect(response.body.welcome).toBe(placeHolderText);
  });
});

describe('HomeController.ts get CustomLinks method call', () => {
  it('should call the method without any params', async () => {
    const response = await homeController.getCustomLinks();
    expect(response).not.toBe(null);
  });

  it('should call the method with type links', async () => {
    const response = await homeController.getCustomLinks(null, 'links');
    expect(response).not.toBe(null);
  });

  it('should call the method with type pages', async () => {
    const response = await homeController.getCustomLinks(null, 'pages');
    expect(response).not.toBe(null);
  });

  it('should call the method with lang param', async () => {
    const response = await homeController.getCustomLinks('ZH_CN');
    expect(response).not.toBe(null);
  });

});

describe('HomeController.ts get CustomLinks http request', () => {
  it('should make a GET request', async () => {
    const response = await request(app.getServer()).get('/home/links');
    expect(response.status).toBe(200);
    expect(response.body).not.toBe(null);
  });

  it('should make a GET request for pages', async () => {
    const response = await request(app.getServer()).get('/home/links?type=pages');
    expect(response.status).toBe(200);
    expect(response.body).not.toBe(null);
  });

  it('should make a GET request for pages', async () => {
    const response = await request(app.getServer()).get('/home/links?lang=ZH_CN');
    expect(response.status).toBe(200);
    expect(response.body).not.toBe(null);
  });
});

describe('HomeController.ts get ResourceLinks method call', () => {
  it('should call the method without any params', async () => {
    const response = await homeController.getResourceLinks();
    expect(response).not.toBe(null);
  });
});

describe('HomeController.ts get ResourceLinks http request', () => {
  it('should make a GET request', async () => {
    const response = await request(app.getServer()).get('/home/resources');
    expect(response.body).not.toBe(null);
  });
});

describe('HomeController.ts get MessageCount method call', () => {
  it('should call the method without any params', async () => {
    const response = await homeController.getMessageCount();
    expect(response).not.toBe(null);
  });
});

describe('HomeController.ts get MessageCount http request', () => {
  it('should make a GET request', async () => {
    const response = await request(app.getServer()).get('/home/messageCount');
    expect(response.body).not.toBe(null);
  });
});

describe('HomeController.ts get News Links method call', () => {
  it('should call the method without any params', async () => {
    const response = await homeController.getNewsLinks();
    expect(response).not.toBe(null);
  });
});

describe('HomeController.ts get News Links http request', () => {
  it('should make a GET request', async () => {
    const response = await request(app.getServer()).get('/home/updates');
    expect(response.body).not.toBe(null);
  });
});
