import 'reflect-metadata';
import * as helmet from 'helmet';
import { Container } from 'typedi';
import { Get, JsonController, QueryParam, UseBefore } from 'routing-controllers';

import { FcWelcomeRepository, LinkRepository } from '../../repositories';

@UseBefore(helmet())
@JsonController('/home')
export class HomeController {
  private welcomeRepo: FcWelcomeRepository;
  private linkRepo: LinkRepository;

  constructor() {
    this.welcomeRepo = Container.get(FcWelcomeRepository);
    this.linkRepo = Container.get(LinkRepository);
  }

  @Get('/welcome')
  public async getWelcomeMessage(@QueryParam('lang') lang?: string): Promise<any> {
    return await this.welcomeRepo.find(lang);
  }

  @Get('/links')
  public async getCustomLinks(@QueryParam('lang') lang?: string, @QueryParam('type') type?: string): Promise<any> {
    return await this.linkRepo.find(lang, type);
  }

  @Get('/resources')
  public async getResourceLinks(): Promise<any> {
    return await this.linkRepo.findResourceLinks();
  }

  @Get('/messageCount')
  public async getMessageCount(): Promise<any> {
    return await this.linkRepo.findMessageCount();
  }

  @Get('/updates')
  public async getNewsLinks(): Promise<any> {
    return await this.linkRepo.findNewsLinks();
  }
}
