import 'reflect-metadata';
import { SwaggerDefinition } from '../../utils';
import * as helmet from 'helmet';
import { Get, JsonController, UseBefore } from 'routing-controllers';
import { Container } from 'typedi';

@UseBefore(helmet())
@JsonController()
export class SwaggerController {
  swaggerSpec = Container.get(SwaggerDefinition);

  @Get('/api-docs.json')
  public async getSwagger(): Promise<any> {
    return this.swaggerSpec.getSpec();
  }
}
