import 'reflect-metadata';
import * as request from 'supertest';

import { createTestApp, TestApp } from '../../mocks/mock-app';
import { SwaggerController } from './';

let app: TestApp;
let ctrl: SwaggerController;

beforeAll(async () => {
  app = await createTestApp();
  ctrl = new SwaggerController();
});

afterAll(() => {
  app.destroy();
});

describe('SwaggerController.ts method call', () => {
  it('should call the method', async () => {
    const response = await ctrl.getSwagger();

    expect(response.paths['/api-docs.json']).toEqual({
      'get': {
        'description': '',
        'operationId': 'getSwagger',
        'parameters': [],
        'produces': ['application/json'],
        'tags': [],
      },
    });
  });
});

describe('SwaggerController.ts http request', () => {
  it('should make a GET request', async () => {
    const response = await request(app.getServer()).get('/api-docs.json');

    expect(response.status).toBe(200);
  });
});
