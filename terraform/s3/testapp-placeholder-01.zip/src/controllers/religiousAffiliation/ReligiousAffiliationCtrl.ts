import 'reflect-metadata';
import * as helmet from 'helmet';
import { Container } from 'typedi';
import { Get, JsonController, QueryParam, UseBefore } from 'routing-controllers';

import { ReligiousAffiliationRepository } from '../../repositories';

@UseBefore(helmet())
@JsonController('/religious-affiliation')
export class ReligiousAffiliationController {
  private religiousAffiliationRepo: ReligiousAffiliationRepository;

  constructor() {
    this.religiousAffiliationRepo = Container.get(ReligiousAffiliationRepository);
  }

  @Get('/search')
  public async search(@QueryParam('filter') filter?: any,
                      @QueryParam('page') page?: number,
                      @QueryParam('limit') limit?: number): Promise<any> {

    return await this.religiousAffiliationRepo.search(filter, page, limit);
  }
}
