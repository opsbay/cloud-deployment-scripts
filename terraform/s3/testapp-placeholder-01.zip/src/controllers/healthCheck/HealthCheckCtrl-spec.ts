import 'reflect-metadata';
import * as request from 'supertest';

import { createTestApp, TestApp } from '../../mocks/mock-app';
import { HealthCheckController } from './';

const message: string = 'Service is up!';

let app: TestApp;
let ctrl: HealthCheckController;

beforeAll(async () => {
  app = await createTestApp();
  ctrl = new HealthCheckController();
});

afterAll(() => {
  app.destroy();
});

/*
 * Two different ways to test controllers:
 * 1) Call the method directly
 * 2) Make an http request using chai-http.
 */

describe('getHealthCheck', () => {
  it('should provide a health check', async () => {
    const response = await ctrl.getHealthCheck(false);

    expect(response.message).toEqual(message);
    expect(response.author).toBeUndefined();
    expect(response.description).toBeUndefined();
    expect(response.version).toBeUndefined();
  });

  it('should provide a health check with environmental variables', async () => {
    const response = await ctrl.getHealthCheck(true);

    expect(response.message).toEqual(message);
    expect(response.author).toBeTruthy();
    expect(response.description).toBeTruthy();
    expect(response.version).toBeTruthy();
  });
});

describe('GET /healthCheck', () => {
  it('should provide a health check', async () => {
    const response = await request(app.getServer()).get('/healthCheck');

    expect(response.status).toBe(200);
    expect(response.body.message).toEqual(message);
    expect(response.body.author).toBeUndefined();
    expect(response.body.description).toBeUndefined();
    expect(response.body.version).toBeUndefined();
  });

  it('should provide a health check with environmental variables', async () => {
    const response = await request(app.getServer()).get('/healthCheck?showEnv=true');

    expect(response.status).toBe(200);
    expect(response.body.message).toEqual(message);
    expect(response.body.author).toBeTruthy();
    expect(response.body.description).toBeTruthy();
    expect(response.body.version).toBeTruthy();
  });
});
