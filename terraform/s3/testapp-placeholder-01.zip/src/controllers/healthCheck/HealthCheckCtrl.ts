import 'reflect-metadata';
import * as helmet from 'helmet';
import { Get, JsonController, QueryParam, UseBefore } from 'routing-controllers';

export class HealthCheckResponse {
  public author: string;
  public description: string;
  public version: string;

  constructor(public message: string) {
  }
}

@UseBefore(helmet())
@JsonController('/healthCheck')
export class HealthCheckController {
  @Get()
  public async getHealthCheck(@QueryParam('showEnv') showEnv: boolean): Promise<HealthCheckResponse> {
    const payload = new HealthCheckResponse('Service is up!');

    if (showEnv) {
      const env = process.env;
      payload.author = env.npm_package_author_name;
      payload.description = env.npm_package_description;
      payload.version = env.npm_package_version;
    }

    return payload;
  }
}
