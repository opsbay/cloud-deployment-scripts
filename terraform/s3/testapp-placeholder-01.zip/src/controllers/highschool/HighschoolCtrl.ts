import 'reflect-metadata';
import * as helmet from 'helmet';
import { Container } from 'typedi';
import { Get, JsonController, UseBefore } from 'routing-controllers';

import { FcOptionsRepository } from '../../repositories';

@UseBefore(helmet())
@JsonController('/highschool')
export class HighschoolController {
  private fcOptionsRepo: FcOptionsRepository;

  constructor() {
    this.fcOptionsRepo = Container.get(FcOptionsRepository);
  }

  @Get('/options')
  public async getOptions(): Promise<any> {

    return await this.fcOptionsRepo.getHighSchoolOptions();
  }
}
