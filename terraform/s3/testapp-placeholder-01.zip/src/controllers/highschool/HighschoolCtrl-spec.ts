import 'reflect-metadata';
import * as request from 'supertest';

import { createTestApp, TestApp } from '../../mocks/mock-app';
import { HighschoolController } from './';

let app: TestApp;
let ctrl: HighschoolController;

beforeAll(async () => {
  app = await createTestApp();
  ctrl = new HighschoolController();
});

afterAll(() => {
  app.destroy();
});

describe('methods calls', () => {
  it('should call the method', async () => {
    const response = await ctrl.getOptions();
    expect(response).not.toBe(null);
  });
});

describe('http requests', () => {
  it('should make a GET request', async () => {
    const response = await request(app.getServer()).get('/highschool/options');
    expect(response).not.toBe(null);
    expect(response.status).toBe(200);
  });
});
