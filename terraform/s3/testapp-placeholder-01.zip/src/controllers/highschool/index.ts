export * from './HighschoolCtrl';
