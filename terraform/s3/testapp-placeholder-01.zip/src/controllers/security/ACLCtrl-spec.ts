import 'reflect-metadata';
import * as request from 'supertest';

import { createTestApp, TestApp } from '../../mocks/mock-app';
import { ACLController } from './';

let app: TestApp;
let ctrl: ACLController;

beforeAll(async () => {
  app = await createTestApp();
  ctrl = new ACLController();
});

afterAll(() => {
  app.destroy();
});

describe('methods calls', () => {
  it('should call the method', async () => {
    const response = await ctrl.getPermissions();
    expect(response).not.toBe(null);
  });
});

describe('http requests', () => {
  it('should make a GET request', async () => {
    const response = await request(app.getServer()).get('/security/permissions');
    expect(response).not.toBe(null);
    expect(response.status).toBe(200);
  });
});
