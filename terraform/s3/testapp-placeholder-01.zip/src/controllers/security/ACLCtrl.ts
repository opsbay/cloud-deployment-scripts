import 'reflect-metadata';
import * as helmet from 'helmet';
import { Container } from 'typedi';
import { Get, JsonController, UseBefore } from 'routing-controllers';

import { FcOptionsRepository, ProductsRepository } from '../../repositories';

export enum ACLRoles {
  GUEST,
  STUDENT,
  PARENT,
  COUNSELOR,
  DISTRICT_USER,
  SUPER_USER,
}

export enum Products {
  SUCCESS_PLANNER = 1,
  NAVIANCE_COURSE_PLANNER = 2,
  COLLEGE_PLANNER = 3,
  COURSE_REQUEST_MANAGER = 9,
  LEARNING_STYLE_INVENTORY = 10,
  NAVIANCE_TEST_PREP = 15,
  NAVIANCE_FOR_ELEMENTARY = 16,
  CAREER_KEY = 17,
  TUITION_COACH = 19,
  HOBSONS_LABS = 21,
  DO_WHAT_YOU_ARE = 22,
  ACHIEVE_WORKS = 23,
  DO_WHAT_YOU_ARE_2 = 24,
  CITE_LEARNING_STYLE_INVENTORY = 26,
  MI_ADVANTAGE = 27,
  MI_ADVANTAGE_2 = 28,
  LEARNING_STYLE_INVENTORY_2 = 29,
  NAVIANCE_DISTRICT_COURSE_PLANNER = 31,
  NAVIANCE = 104,
}

export class ACLPermission {
  role: string;
  resources: {
    [name: string]: string[],
  } = {};

  public addPrivilege(resourceName: string, privileges: string | string[]) {
    let resource = this.resources[resourceName];

    if (!resource) {
      resource = this.resources[resourceName] = [];
    }

    [].concat(privileges).forEach(privilege => {
      resource.push(privilege);
    });
  }

  public isAllowed(resourceName: string, privileges: string | string[]) {
    let resource = this.resources[resourceName];

    if (resource) {
      return [].concat(privileges).every(privilege => {
        return resource.indexOf(privilege) !== -1;
      });
    }

    return false;
  }
}

@UseBefore(helmet())
@JsonController('/security')
export class ACLController {
  private fcOptionsRepo: FcOptionsRepository;
  private productsRepo: ProductsRepository;

  constructor() {
    this.fcOptionsRepo = Container.get(FcOptionsRepository);
    this.productsRepo = Container.get(ProductsRepository);
  }

  @Get('/permissions')
  public async getPermissions(): Promise<any> {
    // TODO: get current authenticated user role & highSchoolId
    const highSchoolId = '88801USPU';
    const role = ACLRoles.STUDENT;
    const permissions: ACLPermission = new ACLPermission();

    permissions.role = 'GUEST';

    const hsOptions: any = await this.fcOptionsRepo.getHighSchoolOptions();
    const products: any[] = await this.productsRepo.getProductsByHighSchool(highSchoolId);

    if (role === ACLRoles.STUDENT) {
      permissions.role = 'STUDENT';
      this.fillStudentPrivileges(permissions, hsOptions, products);
    } else if (role === ACLRoles.PARENT) {
      permissions.role = 'PARENT';
      this.fillParentPrivileges(permissions, hsOptions, products);
    }

    return permissions;
  }

  private fillStudentPrivileges(permissions: ACLPermission, hsOptions: any, products: any[]) {
    permissions.addPrivilege('header', [
      'manageAccount',
      'colleges',
      'aboutMe',
      'myPlanner',
      'application:edit',
    ]);

    /*
     * homepage section
     */

    // leftmenu - my colleges section
    if (hsOptions.can_edit_prospective) {
      permissions.addPrivilege('home', 'collegesImThinkingAbout');
    }

    if (hsOptions.can_add_applications) {
      permissions.addPrivilege('home', 'collegesImApplyingTo');
    }

    //leftmenu - pages
    permissions.addPrivilege('home', 'pages');

    //leftmenu - resources
    if(hsOptions.curriculum_on) {
      permissions.addPrivilege('home', 'resourcesLessons');
    }

    //leftmenu - resources
    if (this.verifyProduct(products, Products.NAVIANCE_TEST_PREP)) {
      permissions.addPrivilege('home', 'resourcesTestPrep');
    }

    //leftmenu - links
    permissions.addPrivilege('home', 'links');

    //left - contact Link
    if(hsOptions.contact_on) {
      permissions.addPrivilege('home', 'contact');
    }

    //left - document library
    permissions.addPrivilege('home', 'documentLibrary');

    //center - what's new
    permissions.addPrivilege('home', 'whatsnew');

    //center - welcome
    permissions.addPrivilege('home', 'welcome');

    //center - updates
    permissions.addPrivilege('home', 'updates');

    /*
     * college section
     */
    permissions.addPrivilege('colleges', [
      // my colleges zone
      'lettersOfRecommendation',
    ]);

    // my colleges zone
    if (hsOptions.can_edit_prospective) {
      permissions.addPrivilege('colleges', 'collegesImThinkingAbout');
    }

    if (hsOptions.can_add_applications) {
      permissions.addPrivilege('colleges', 'collegesImApplyingTo');
    }

    if (hsOptions.active_match_events_on) {
      permissions.addPrivilege('colleges', 'upcomingCollegeEvents');
    }

    if (hsOptions.visits_on) {
      permissions.addPrivilege('colleges', 'upcomingCollegeVisits');
    }

    // college research zone
    if (hsOptions.supermatch_on) {
      permissions.addPrivilege('colleges', 'superMatch');
    }

    if (hsOptions.college_match_on) {
      permissions.addPrivilege('colleges', 'collegeMatch');
    }

    if (hsOptions.college_compare_on) {
      permissions.addPrivilege('colleges', 'collegeCompare');
    }

    if (hsOptions.college_profiles_on) {
      permissions.addPrivilege('colleges', 'collegeLookup');
    }

    if (hsOptions.college_search_on) {
      permissions.addPrivilege('colleges', 'collegeSearch');
    }

    if (hsOptions.resources_on) {
      permissions.addPrivilege('colleges', 'collegeResources');
    }

    if (hsOptions.maps_on) {
      permissions.addPrivilege('colleges', 'collegeMaps');
    }

    if (hsOptions.graphs_on) {
      permissions.addPrivilege('colleges', 'scattergrams');
    }

    if (hsOptions.acceptances_on) {
      permissions.addPrivilege('colleges', 'acceptanceHistory');
    }

    if (hsOptions.summer_programs_on) {
      permissions.addPrivilege('colleges', 'enrichmentPrograms');
    }

    // scholarships and money zone
    if (hsOptions.scholarship_match_on) {
      permissions.addPrivilege('colleges', 'scholarshipMatch');
    }

    if (hsOptions.scholarships_on) {
      permissions.addPrivilege('colleges', ['scholarshipList', 'scholarshipApplications']);
    }

    if (hsOptions.national_scholarship_on) {
      permissions.addPrivilege('colleges', 'nationalScholarshipSearch');
    }

    if (hsOptions.tuition_coach_on) {
      permissions.addPrivilege('colleges', 'tuitionCoach');
    }

    /*
     * careers section
     */
    permissions.addPrivilege('careers', []);

    if (hsOptions.resources_on) {
      permissions.addPrivilege('careers', 'favoriteCareersAndClusters');
      permissions.addPrivilege('careers', 'exploreCareers');
    }

    if (hsOptions.career_search_on) {
      permissions.addPrivilege('careers', 'exploreCareersAndClusters');

      if (this.verifyProduct(products, Products.DO_WHAT_YOU_ARE) && hsOptions.dwya_on) {
        permissions.addPrivilege('careers', 'personalityType');
      }

      if (hsOptions.dwya2_on) {
        permissions.addPrivilege('careers', 'doWhatYouAre');
      }

      permissions.addPrivilege('careers', 'clusterFinder');

      if (hsOptions.holland_on) {
        permissions.addPrivilege('careers', 'careerInterestProfiler');
      }

      if (hsOptions.career_key_on) {
        permissions.addPrivilege('careers', 'careerKey');
      }
    }

    if (hsOptions.road_trip_nation_on) {
      permissions.addPrivilege('careers', 'roadtripNation');
    }

    /*
    *courses section
    */
    if (hsOptions.resources_on) {
      permissions.addPrivilege('header', 'courses');
      permissions.addPrivilege('courses', 'interestingCourses');
      permissions.addPrivilege('courses', 'thoughtsAboutMyCoursePlans');
    }

    if (hsOptions.course_history_on) {
      permissions.addPrivilege('courses', 'courseHistory');
    }

    if (hsOptions.course_requests_on) {
      permissions.addPrivilege('courses', 'courseRequests');
    }

    if (hsOptions.course_planner_on) {
      permissions.addPrivilege('courses', 'coursePlanner');
    }

    /*
     * about me section
     */
    permissions.addPrivilege('aboutMe', [
      // success plan zone
      'goals',
      'tasks',
      // my assessments
      'careerInterestProfiler',
      'clusterFinder',
      // interesting things about me zone
      'portfolio',
      'favoriteColleges',
      'favoriteCareersAndClusters',
      'resume',
      'documents',
      'journal',
      'checklist',
      'completedSurveys',
      // official things zone
      'navianceStudentMobileApp',
    ]);

    // my assessments zone
    if (hsOptions.strengths_explorer_on) {
      permissions.addPrivilege('aboutMe', 'strengthsExplorer');
    }

    if (hsOptions.dwya2_on) {
      permissions.addPrivilege('aboutMe', 'doWhatYouAre');
    }

    if (hsOptions.lsi_on) {
      permissions.addPrivilege('aboutMe', 'learningStyle');
    }

    if (hsOptions.lsi2_on) {
      permissions.addPrivilege('aboutMe', 'learningStyleInventory');
    }

    if (hsOptions.mia_on) {
      permissions.addPrivilege('aboutMe', 'miAdvantage');
    }

    if (hsOptions.mia2_on) {
      permissions.addPrivilege('aboutMe', 'miAdvantage2');
    }

    if (hsOptions.career_key_on) {
      permissions.addPrivilege('aboutMe', 'careerKey');
    }

    // interesting things about me zone
    if (hsOptions.game_plan_on) {
      permissions.addPrivilege('aboutMe', 'gamePlan');
    }

    // official things zone
    permissions.addPrivilege('aboutMe', 'myProfile');
    permissions.addPrivilege('aboutMe', 'myAccount');
    permissions.addPrivilege('aboutMe', 'testScores');

    /*
     * my planner section
     */
    permissions.addPrivilege('myPlanner', []);

    /*
     * PRODUCT BASED PERMISSIONS
     */
    if (this.verifyProduct(products, Products.SUCCESS_PLANNER)) {
      permissions.addPrivilege('other', 'successPlanner');
    }

    let hasCourses = false;

    if (this.verifyProduct(products, Products.COURSE_REQUEST_MANAGER) && hsOptions.course_requests_on) {
      permissions.addPrivilege('other', 'courseRequests');
      hasCourses = true;
    }

    if (this.verifyProduct(products, Products.NAVIANCE_COURSE_PLANNER) ||
      this.verifyProduct(products, Products.NAVIANCE_DISTRICT_COURSE_PLANNER)) {
      if (hsOptions.course_planner_on) {
        permissions.addPrivilege('other', 'coursePlanner');
      }

      if (hsOptions.plan_alerts_on) {
        permissions.addPrivilege('other', 'planAlerts');
      }

      hasCourses = true;
    }

    if (hasCourses) {
      permissions.addPrivilege('header', 'courses');
    }

    if (hsOptions.course_history_on) {
      permissions.addPrivilege('other', 'courseHistory');
    }

    if (this.verifyProduct(products, Products.COLLEGE_PLANNER)) {
      permissions.addPrivilege('header', 'colleges');
      permissions.addPrivilege('other', 'journal');

      if (hsOptions.maps_on) {
        permissions.addPrivilege('other', 'maps');
      }
    }

    if (this.verifyProduct(products, Products.NAVIANCE)) {
      permissions.addPrivilege('header', 'careers');
    }

    if ((this.verifyProduct(products, Products.LEARNING_STYLE_INVENTORY) ||
      this.verifyProduct(products, Products.CITE_LEARNING_STYLE_INVENTORY)) &&
      hsOptions.lsi_on) {
      permissions.addPrivilege('other', 'lsi');
    }

    if ((this.verifyProduct(products, Products.LEARNING_STYLE_INVENTORY_2) ||
      this.verifyProduct(products, Products.ACHIEVE_WORKS)) &&
      hsOptions.lsi2_on) {
      permissions.addPrivilege('other', 'lsi2');
    }

    if (this.verifyProduct(products, Products.MI_ADVANTAGE) && hsOptions.mia_on) {
      permissions.addPrivilege('other', 'mia');
    }

    if ((this.verifyProduct(products, Products.MI_ADVANTAGE_2) ||
      this.verifyProduct(products, Products.ACHIEVE_WORKS)) &&
      hsOptions.mia2_on) {
      permissions.addPrivilege('other', 'mia2');
    }

    if (this.verifyProduct(products, Products.DO_WHAT_YOU_ARE) && hsOptions.dwya_on) {
      permissions.addPrivilege('other', 'dwya');
    }

    if ((this.verifyProduct(products, Products.DO_WHAT_YOU_ARE_2) ||
      this.verifyProduct(products, Products.ACHIEVE_WORKS)) &&
      hsOptions.dwya2_on) {
      permissions.addPrivilege('other', 'dwya2');
    }

    if (this.verifyProduct(products, Products.CAREER_KEY) && hsOptions.career_key_on) {
      permissions.addPrivilege('other', 'careerKey');
    }

    if (this.verifyProduct(products, Products.TUITION_COACH) && hsOptions.tuition_coach_on) {
      permissions.addPrivilege('other', 'tuitionCoach');
    }

    if (this.verifyProduct(products, Products.NAVIANCE_TEST_PREP) ||
      this.verifyProduct(products, Products.NAVIANCE_FOR_ELEMENTARY) ||
      this.verifyProduct(products, Products.HOBSONS_LABS)) {
      permissions.addPrivilege('other', 'method');
    }
  }

  private fillParentPrivileges(permissions: ACLPermission, hsOptions: any, products: any[]) {
    permissions.addPrivilege('header', [
      'manageAccount',
      'aboutMe',
    ]);

    // leftmenu - my colleges section
    if (hsOptions.can_edit_prospective) {
      permissions.addPrivilege('home', 'collegesImThinkingAbout');
    }

    if (hsOptions.can_add_applications) {
      permissions.addPrivilege('home', 'collegesImApplyingTo');
    }

    //leftmenu - pages
    permissions.addPrivilege('home', 'pages');

    //leftmenu - links
    permissions.addPrivilege('home', 'links');

    //leftmenu - resources
    if(hsOptions.curriculum_on) {
      permissions.addPrivilege('home', 'resourcesLessons');
    }
    
    //center - what's new
    permissions.addPrivilege('home', 'whatsnew');

    //center - welcome
    permissions.addPrivilege('home', 'welcome');

    //center - msgcount
    permissions.addPrivilege('home', 'msgCount');

    //center - updates
    permissions.addPrivilege('home', 'updates');

    permissions.addPrivilege('colleges', []);
    permissions.addPrivilege('careers', []);
    permissions.addPrivilege('aboutMe', [
      'myProfile',
      'myInbox',
      'myAccount',
      'studentProfile',
      'studentInbox',
    ]);
    permissions.addPrivilege('myPlanner', []);

    /*
     * PRODUCT BASED PERMISSIONS
     */
    if (this.verifyProduct(products, Products.SUCCESS_PLANNER)) {
      permissions.addPrivilege('other', 'successPlanner');
    }

    let hasCourses = false;

    if (this.verifyProduct(products, Products.COURSE_REQUEST_MANAGER) && hsOptions.course_requests_on) {
      permissions.addPrivilege('other', 'courseRequests');
      hasCourses = true;
    }

    if (this.verifyProduct(products, Products.NAVIANCE_COURSE_PLANNER) ||
      this.verifyProduct(products, Products.NAVIANCE_DISTRICT_COURSE_PLANNER)) {
      if (hsOptions.course_planner_on) {
        permissions.addPrivilege('other', 'coursePlanner');
      }

      if (hsOptions.plan_alerts_on) {
        permissions.addPrivilege('other', 'planAlerts');
      }

      hasCourses = true;
    }

    if (hasCourses) {
      permissions.addPrivilege('header', 'courses');
    }

    if (this.verifyProduct(products, Products.COLLEGE_PLANNER)) {
      permissions.addPrivilege('header', 'colleges');
      permissions.addPrivilege('other', 'journal');

      if (hsOptions.maps_on) {
        permissions.addPrivilege('other', 'maps');
      }
    }

    if (this.verifyProduct(products, Products.NAVIANCE)) {
      permissions.addPrivilege('header', 'careers');
    }

    if ((this.verifyProduct(products, Products.LEARNING_STYLE_INVENTORY) ||
      this.verifyProduct(products, Products.CITE_LEARNING_STYLE_INVENTORY)) &&
      hsOptions.lsi_on) {
      permissions.addPrivilege('other', 'lsi');
    }

    if ((this.verifyProduct(products, Products.LEARNING_STYLE_INVENTORY_2) ||
      this.verifyProduct(products, Products.ACHIEVE_WORKS)) &&
      hsOptions.lsi2_on) {
      permissions.addPrivilege('other', 'lsi2');
    }

    if (this.verifyProduct(products, Products.MI_ADVANTAGE) && hsOptions.mia_on) {
      permissions.addPrivilege('other', 'mia');
    }

    if ((this.verifyProduct(products, Products.MI_ADVANTAGE_2) ||
      this.verifyProduct(products, Products.ACHIEVE_WORKS)) &&
      hsOptions.mia2_on) {
      permissions.addPrivilege('other', 'mia2');
    }

    if (this.verifyProduct(products, Products.DO_WHAT_YOU_ARE) && hsOptions.dwya_on) {
      permissions.addPrivilege('other', 'dwya');
    }

    if ((this.verifyProduct(products, Products.DO_WHAT_YOU_ARE_2) ||
      this.verifyProduct(products, Products.ACHIEVE_WORKS)) &&
      hsOptions.dwya2_on) {
      permissions.addPrivilege('other', 'dwya2');
    }

    if (this.verifyProduct(products, Products.CAREER_KEY) && hsOptions.career_key_on) {
      permissions.addPrivilege('other', 'careerKey');
    }

    if (this.verifyProduct(products, Products.TUITION_COACH) && hsOptions.tuition_coach_on) {
      permissions.addPrivilege('other', 'tuitionCoach');
    }

    if (this.verifyProduct(products, Products.NAVIANCE_TEST_PREP) ||
      this.verifyProduct(products, Products.NAVIANCE_FOR_ELEMENTARY) ||
      this.verifyProduct(products, Products.HOBSONS_LABS)) {
      permissions.addPrivilege('other', 'method');
    }

    /*
     * careers section
     */
    permissions.addPrivilege('careers', []);

    if (hsOptions.resources_on) {
      permissions.addPrivilege('careers', 'favoriteCareersAndClusters');
      permissions.addPrivilege('careers', 'exploreCareers');
    }

    if (hsOptions.career_search_on) {
      permissions.addPrivilege('careers', 'exploreCareersAndClusters');

      if (this.verifyProduct(products, Products.DO_WHAT_YOU_ARE) && hsOptions.dwya_on) {
        permissions.addPrivilege('careers', 'personalityType');
      }

      if (hsOptions.dwya2_on) {
        permissions.addPrivilege('careers', 'doWhatYouAre');
      }

      permissions.addPrivilege('careers', 'clusterFinder');

      if (hsOptions.holland_on) {
        permissions.addPrivilege('careers', 'careerInterestProfiler');
      }

      if (hsOptions.career_key_on) {
        permissions.addPrivilege('careers', 'careerKey');
      }
    }

    if (hsOptions.road_trip_nation_on) {
      permissions.addPrivilege('careers', 'roadtripNation');
    }

    /*
    *courses section
    */
    if (hsOptions.resources_on) {
      permissions.addPrivilege('header', 'courses');
      permissions.addPrivilege('courses', 'interestingCourses');
      permissions.addPrivilege('courses', 'thoughtsAboutMyCoursePlans');
    }

    if (hsOptions.course_history_on) {
      permissions.addPrivilege('courses', 'courseHistory');
    }

    if (hsOptions.course_requests_on) {
      permissions.addPrivilege('courses', 'courseRequests');
    }

    if (hsOptions.course_planner_on) {
      permissions.addPrivilege('courses', 'coursePlanner');
    }
  }

  private verifyProduct(products: any[], productId: number) {
    return products.some(product => {
      return product.id === productId;
    });
  }
}
