import 'reflect-metadata';
import * as helmet from 'helmet';
import { Container } from 'typedi';
import { Get, JsonController, QueryParam, UseBefore } from 'routing-controllers';

import { SportsRepository } from '../../repositories';

@UseBefore(helmet())
@JsonController('/sports')
export class SportsController {
  private sportsRepo: SportsRepository;

  constructor() {
    this.sportsRepo = Container.get(SportsRepository);
  }

  @Get('/search')
  public async search(@QueryParam('filter') filter?: any,
                      @QueryParam('page') page?: number,
                      @QueryParam('limit') limit?: number): Promise<any> {

    return await this.sportsRepo.search(filter, page, limit);
  }
}
