import 'reflect-metadata';
import * as request from 'supertest';

import { createTestApp, TestApp } from '../../mocks/mock-app';
import { CareerController } from './';

let app: TestApp;
let careerController: CareerController;

beforeAll(async () => {
  app = await createTestApp();
  careerController = new CareerController();
});

afterAll(() => {
  app.destroy();
});

describe('get career search', () => {
  it('should call the search method for careers', async () => {
    const response = await careerController.search();
    expect(response).not.toBe(null);
  });
});

describe('GET /career/search', () => {
  it('should make a GET request', async () => {
    const response = await request(app.getServer()).get('/career/search');
    expect(response.status).toBe(200);
  });
});

describe('get career cluster search', () => {
  it('should call the search method for career cluster', async () => {
    const response = await careerController.searchClusters();
    expect(response).not.toBe(null);
  });
});

describe('GET /career/searchClusters', () => {
  it('should make a GET request', async () => {
    const response = await request(app.getServer()).get('/career/search');
    expect(response.status).toBe(200);
  });
});
