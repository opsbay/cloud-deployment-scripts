import 'reflect-metadata';
import * as request from 'supertest';
import { noop } from 'lodash';
import {
  Controller,
  ContentType,
  JsonResponse,
  Middleware,
  MiddlewareInterface,
  UseBefore,
  Body,
  Param,
  QueryParam,
  Get,
  Post,
  UploadedFile,
  UploadedFiles,
  defaultMetadataArgsStorage,
} from 'routing-controllers';

import { createTestApp, TestApp } from '../mocks/mock-app';

let app: TestApp;

describe.only('swagger enabled', () => {
  beforeAll(() => {
    // reset metadata args storage
    defaultMetadataArgsStorage().reset();

    @Middleware()
    class AuthenticatedMiddelware implements MiddlewareInterface {
      use(request: any, response: any, next?: (err?: any) => any): any {
        noop();
      }
    }

    @Controller('api')
      // tslint:disable-next-line:no-unused-variable
    class BasicController {
      @Get('/get.xml')
      @ContentType('application/xml')
      testXmlContentType() {
        noop();
      }

      @UseBefore(AuthenticatedMiddelware)
      @Get('/get.json')
      @ContentType('application/json')
      testJsonContentType() {
        noop();
      }

      @Get('/get2.json')
      @JsonResponse()
      testJsonContentType2() {
        noop();
      }

      @Post('/post.empty')
      testPost() {
        noop();
      }

      @Post('/post/body')
      testPostBody(@Body() body: any) {
        noop();
      }

      @Get('/get/:id')
      testParam(@Param('id') id: number) {
        noop();
      }

      @Get('/get/query')
      testQueryParam(@QueryParam('id') id: string) {
        noop();
      }

      @Post('/post/file')
      testFile(@UploadedFile('file') file: any) {
        noop();
      }

      @Post('/post/files')
      testFiles(@UploadedFiles('files') files: any) {
        noop();
      }

    }
  });

  beforeAll(async () => {
    app = await createTestApp();
  });

  afterAll(() => {
    app.destroy();
  });

  describe('get swagger.json expected structure', () => {
    it('should do stuff', async () => {
      const response = await request(app.getServer()).get('/api-docs.json');
      expect(response.status).toBe(200);
      expect(response.header['content-type']).toBe('application/json; charset=utf-8');
      let definition = response.body;

      expect(definition.paths['api/get.xml']).toEqual({
        'get': {
          'operationId': 'testXmlContentType',
          'description': '',
          'produces': [
            'application/xml',
          ],
          'parameters': [],
          'tags': ['api'],
        },
      });

      expect(definition.paths['api/get.json']).toEqual({
        'get': {
          'operationId': 'testJsonContentType',
          'description': '(-AuthenticatedMiddelware)',
          'produces': [
            'application/json',
          ],
          'parameters': [],
          'tags': ['api'],
        },
      });

      expect(definition.paths['api/get2.json']).toEqual({
        'get': {
          'operationId': 'testJsonContentType2',
          'description': '',
          'produces': [
            'application/json',
          ],
          'parameters': [],
          'tags': ['api'],
        },
      });

      expect(definition.paths['api/post.empty']).toEqual({
        'post': {
          'operationId': 'testPost',
          'description': '',
          'produces': [],
          'parameters': [],
          'tags': ['api'],
        },
      });

      expect(definition.paths['api/post/body']).toEqual({
        'post': {
          'operationId': 'testPostBody',
          'description': '',
          'produces': [],
          'parameters': [
            {
              'in': 'body',
              'name': null,
              'type': 'Object',
              'required': false,
            },
          ],
          'tags': ['api'],
        },
      });

      expect(definition.paths['api/get/:id']).toEqual({
        'get': {
          'operationId': 'testParam',
          'description': '',
          'produces': [],
          'parameters': [
            {
              'in': 'param',
              'name': 'id',
              'type': 'Number',
              'required': true,
            },
          ],
          'tags': ['api'],
        },
      });

      expect(definition.paths['api/get/query']).toEqual({
        'get': {
          'operationId': 'testQueryParam',
          'description': '',
          'produces': [],
          'parameters': [
            {
              'in': 'query',
              'name': 'id',
              'type': 'String',
              'required': false,
            },
          ],
          'tags': ['api'],
        },
      });

      expect(definition.paths['api/post/file']).toEqual({
        'post': {
          'operationId': 'testFile',
          'description': '',
          'produces': [],
          'parameters': [
            {
              'in': 'file',
              'name': 'file',
              'type': 'file',
              'required': false,
            },
          ],
          'tags': ['api'],
        },
      });

      expect(definition.paths['api/post/files']).toEqual({
        'post': {
          'operationId': 'testFiles',
          'description': '',
          'produces': [],
          'parameters': [
            {
              'in': 'files',
              'name': 'files',
              'required': false,
            },
          ],
          'tags': ['api'],
        },
      });
    });
  });
});
